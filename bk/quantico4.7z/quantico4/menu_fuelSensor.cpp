/****************************************************************************
* Project: Battery System
*
* 2016-05-11-19.38
* jcaf @ jcafOpenSuse
*
* Copyright 2016 Juan Carlos Agüero Flores
*
* Licensed under the Apache License, Version 2.0 (the "License"));
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*     http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
****************************************************************************/
#include <Arduino.h>
#include "system.h"
#include "utils.h"

#include "vscroll.h"
#include "lcd_fxaux.h"
#include "ikey.h"
#include "kb.h"

#include "menu.h"
#include "menu_fuelSensor.h"
#include "fuelsensor.h"
#include "menu_mainMenu.h"

#define DTOSTRF_SIGN_POS 1
//#define PARAM_STR_LENGTH (7+1)
char PARAM0str[7+1];//="0000.00";
char PARAM1str[7+1];//="0000.00";
char PARAM2str[7+1];//="0000.00";

struct _setnum
{
    uint8_t param;

    struct _digit
    {
        uint8_t position;

#define BLINK_TOGGLE_BLANK 0
#define BLINK_TOGGLE_NOBLANK 1
        struct _blink
        {
            uint8_t sm0;

            unsigned long last_millis;

            struct _bf
            {
                unsigned toggle:1;
                unsigned __a:7;
            } bf;

        } blink;
    } digit;

    union
    {
        struct //_bf
        {
            unsigned check_range_limit:1;
            unsigned error_consistency_lenght:1;
            unsigned error_consistency_volume:1;
            unsigned error_equalzero_length:1;
            unsigned error_equalzero_volume:1;
            unsigned __a:3;
        } bf;
        uint8_t bitflag;
    };

    float n_entered;

} setnum;


////////////////////////////////////////////////////////////////////////////////////////////////////////////
struct _menuFuelSensor_warning
{
    int sm0;
    int sm1;
} menuFuelSensor_warning;

static inline void menuFuelSensor_warning_fxKey0(void)
{
}
static inline void menuFuelSensor_warning_fxKey1(void)
{
    if (--menuFuelSensor_warning.sm1 < 0)
        menuFuelSensor_warning.sm1 = 0;
    else
        menuFuelSensor_warning.sm0 = 1;
}
static inline void menuFuelSensor_warning_fxKey2(void)
{
    if (++menuFuelSensor_warning.sm1 > 1)
    {
        menuFuelSensor_warning.sm1 = 0;

        taskman_fuelSensor.sign = TASKMAN_SIGN_ENTER;

        taskman_fuelSensor.sm0 =1;
    }
    else
        menuFuelSensor_warning.sm0 = 1;
}
static inline void menuFuelSensor_warning_fxKey3(void)
{
}
static inline void menuFuelSensor_warning_fxKey4(void)
{
}

PTRFX_retVOID const menuFuelSensor_warning_fxKey[KB_NUM_KEYS] PROGMEM =
{
    menuFuelSensor_warning_fxKey0, menuFuelSensor_warning_fxKey1, menuFuelSensor_warning_fxKey2,
    menuFuelSensor_warning_fxKey3, menuFuelSensor_warning_fxKey4
};

//-----------------------------------------------------------------------------------------------------------
static void menuFuelSensor_warning_job(void)
{
    if (menuFuelSensor_warning.sm0 == 0)
    {
        kb_stackPush();
        kb_change_keyDo_pgm(menuFuelSensor_warning_fxKey);

        menuFuelSensor_warning.sm1 = 0;
        menuFuelSensor_warning.sm0++;
    }

    if (menuFuelSensor_warning.sm0 == 1)
    {
        if (menuFuelSensor_warning.sm1 == 0)
        {
            sysPrint_lcdPrintPSTR(0, STR_CENTER, PSTR("[WARNING]"));
            sysPrint_lcdPrintPSTR(1, STR_CENTER, PSTR("This sensor use"));
            sysPrint_lcdPrintPSTR(2, STR_CENTER, PSTR("diesel, biodisel,"));
            sysPrint_lcdPrintPSTR(3, STR_CENTER, PSTR("kerosene, gasoline"));
        }

        else if (menuFuelSensor_warning.sm1 == 1)
        {
            sysPrint_lcdPrintPSTR(0, STR_CENTER, PSTR("Do not measure"));
            sysPrint_lcdPrintPSTR(1, STR_CENTER, PSTR("conductive material"));
            sysPrint_lcdPrintPSTR(2, STR_CENTER, PSTR("like water, etc."));
            sysPrint_lcdPrintPSTR(3, STR_CENTER, PSTR("(Press any key...)"));
        }

        menuFuelSensor_warning.sm0 = -1;
    }
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////

VScroll VS_menuFuelSensor_mainMenu;

struct _menuFuelSensor_mainMenu
{
    int8_t sm0;
    //int8_t sm1;
} menuFuelSensor_mainMenu;

static inline void menuFuelSensor_mainMenu_fxKey0(void)
{
}
static inline void menuFuelSensor_mainMenu_fxKey1(void)
{
    VS_menuFuelSensor_mainMenu.sign_up();
}
static inline void menuFuelSensor_mainMenu_fxKey2(void)
{
    VS_menuFuelSensor_mainMenu.sign_down();
}

static inline void menuFuelSensor_mainMenu_fxKey3(void)
{
    uint8_t posc = VS_menuFuelSensor_mainMenu.get_markPosc();

    taskman_fuelSensor.sm1 = posc+1;
    taskman_fuelSensor.sign = TASKMAN_SIGN_ENTER;

    menuFuelSensor_mainMenu.sm0 = 1;
}
static inline void menuFuelSensor_mainMenu_fxKey4(void)
{
    taskman_mainMenu.sm0 = 0;
    taskman_fuelSensor.sm0 = 0;
    kb_stackPop();
    kb_stackPop();
}

PTRFX_retVOID const menuFuelSensor_mainMenu_fxKey[KB_NUM_KEYS] PROGMEM =
{
    menuFuelSensor_mainMenu_fxKey0, menuFuelSensor_mainMenu_fxKey1, menuFuelSensor_mainMenu_fxKey2,
    menuFuelSensor_mainMenu_fxKey3, menuFuelSensor_mainMenu_fxKey4
};

//-----------------------------------------------------------------------------------------------------------
static void menuFuelSensor_mainMenu_job(void)
{
#define MENU_FUELSENSOR_OPTIONS 4

    String db_menuFuelSensor_mainMenu[MENU_FUELSENSOR_OPTIONS] =
    {
        str_clearPrint("1] MODEL OF SENSOR", 0),
        str_clearPrint("2] CALIBRATION", 0),
        str_clearPrint("3] OUTPUT TYPE", 0),
        str_clearPrint("4] FUEL TANK", 0),
    };

    if (menuFuelSensor_mainMenu.sm0 == 0)//siempre SOLO cuando se entra!!!!
    {
        kb_stackPush();
        kb_change_keyDo_pgm(menuFuelSensor_mainMenu_fxKey);

        VS_menuFuelSensor_mainMenu.init(db_menuFuelSensor_mainMenu, MENU_FUELSENSOR_OPTIONS, dispShowBuff, 2, FEAT_MARK_ON);

        menuFuelSensor_mainMenu.sm0++;
    }

    if (menuFuelSensor_mainMenu.sm0 == 1)
    {
        lcd.clear();
        sysPrint_lcdPrintPSTR(LCD_ROW_0, 0, PSTR("[FUEL SENSOR]"));
        sysPrint_lcdPrintPSTR(LCD_ROW_1, 0, PSTR("Current: 1234.56 gal"));

        menuFuelSensor_mainMenu.sm0 =-1;
    }

    VS_menuFuelSensor_mainMenu.set_db(db_menuFuelSensor_mainMenu);//x local db
    VS_menuFuelSensor_mainMenu.job();
    lcd_show_disp(LCD_ROW_2);
}
////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////
VScroll VS_menuFuelSensor_modelOfsensor;

#define FUELSENSOR_DB_MODEL_MAX 3
const struct _fuelsensor_db_modelOfsensor
{
    char name[15];//9 char +1 '\0'
}
fuelsensor_db_modelOfsensor[FUELSENSOR_DB_MODEL_MAX] PROGMEM=
{
    "JT606X",
    "LLS 20160",
    "LLS 20230",
};
inline static void fuelsensor_get_modelOfsensor_name(uint8_t model, char *buf)
{
    strcpy_P(buf, (char *) &fuelsensor_db_modelOfsensor[model].name );
}

static inline void menuFuelSensor_modelOfsensor_fxKey0(void)
{
}
static inline void menuFuelSensor_modelOfsensor_fxKey1(void)
{
    VS_menuFuelSensor_modelOfsensor.sign_up();
}
static inline void menuFuelSensor_modelOfsensor_fxKey2(void)
{
    VS_menuFuelSensor_modelOfsensor.sign_down();
}
static inline void menuFuelSensor_modelOfsensor_fxKey3(void)
{
    fuelsensor.model= VS_menuFuelSensor_modelOfsensor.get_markPosc();

    char buf[10];
    fuelsensor_get_modelOfsensor_name(fuelsensor.model, buf);
    sysPrint_lcdPrint(1, 0, "Current: " + String(buf));

}
static inline void menuFuelSensor_modelOfsensor_fxKey4(void)
{
    taskman_fuelSensor.sm1 = 0;
    kb_stackPop();
}

PTRFX_retVOID const menuFuelSensor_modelOfsensor_fxKey[KB_NUM_KEYS] PROGMEM =
{
    menuFuelSensor_modelOfsensor_fxKey0, menuFuelSensor_modelOfsensor_fxKey1, menuFuelSensor_modelOfsensor_fxKey2,
    menuFuelSensor_modelOfsensor_fxKey3, menuFuelSensor_modelOfsensor_fxKey4
};

//-----------------------------------------------------------------------------------------------------------
struct _menuFuelSensor_modelOfsensor
{
    int sm0;
} menuFuelSensor_modelOfsensor;

static void menuFuelSensor_modelOfsensor_job(void)
{
    char buf[10];

    String db_menuFuelSensor_modelOfsensor_local[FUELSENSOR_DB_MODEL_MAX];

    for (uint8_t i=0; i<FUELSENSOR_DB_MODEL_MAX; i++)
    {
        fuelsensor_get_modelOfsensor_name(i, buf);
        db_menuFuelSensor_modelOfsensor_local[i] = str_clearPrint(String(i+1)+ "] "+ String(buf), 3);
    }

    if (menuFuelSensor_modelOfsensor.sm0 == 0)
    {
        kb_stackPush();
        kb_change_keyDo_pgm(menuFuelSensor_modelOfsensor_fxKey);

        lcd.clear();

        VS_menuFuelSensor_modelOfsensor.init(db_menuFuelSensor_modelOfsensor_local, FUELSENSOR_DB_MODEL_MAX, dispShowBuff, 2, FEAT_MARK_ON);

        sysPrint_lcdPrintPSTR(0, 0, PSTR("[MODEL OF SENSOR]"));

        fuelsensor_get_modelOfsensor_name(fuelsensor.model, buf);
        sysPrint_lcdPrint(1, 0, "Current: " + String(buf));


        menuFuelSensor_modelOfsensor.sm0 = -1;
    }

    VS_menuFuelSensor_modelOfsensor.set_db(db_menuFuelSensor_modelOfsensor_local);//x la naturaleza "local"
    VS_menuFuelSensor_modelOfsensor.job();
    //lcd_show_disp(LCD_ROW_2,LCD_ROW_2+(FUELSENSOR_DB_MODEL_MAX-1));//AUTOMATIZAR CON Vertical Scroll
    lcd_show_disp(LCD_ROW_2);//AUTOMATIZAR CON Vertical Scroll
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////
VScroll VS_menuFuelSensor_calibration;

static inline void menuFuelSensor_calibration_fxKey0(void)
{
}
static inline void menuFuelSensor_calibration_fxKey1(void)
{
    VS_menuFuelSensor_calibration.sign_up();
}
static inline void menuFuelSensor_calibration_fxKey2(void)
{
    VS_menuFuelSensor_calibration.sign_down();
}

static inline void menuFuelSensor_calibration_fxKey3(void)
{
    taskman_fuelSensor.sign = TASKMAN_SIGN_ENTER;

    uint8_t opt = VS_menuFuelSensor_calibration.get_markPosc();

//    #define FS_DO_FULL_CALIB 1
//    #define FS_DO_ZERO_CALIB 0

    taskman_fuelSensor.sm2 = 1;

    if (opt == 0)
        fuelsensor.calib.bf.do_fullzero = FS_DO_FULL_CALIB;
    else if (opt == 1)
        fuelsensor.calib.bf.do_fullzero = FS_DO_ZERO_CALIB;
    else if (opt == 2)
    {
        taskman_fuelSensor.sm2 = 2;
        taskman_fuelSensor.sm3 = 0;
    }

}
static inline void menuFuelSensor_calibration_fxKey4(void)
{
    taskman_fuelSensor.sm1 = 0;
    kb_stackPop();
}

PTRFX_retVOID const menuFuelSensor_calibration_fxKey[KB_NUM_KEYS] PROGMEM =
{
    menuFuelSensor_calibration_fxKey0, menuFuelSensor_calibration_fxKey1, menuFuelSensor_calibration_fxKey2,
    menuFuelSensor_calibration_fxKey3, menuFuelSensor_calibration_fxKey4
};

//-----------------------------------------------------------------------------------------------------------
struct _menuFuelSensor_calibration
{
    int8_t sm0;
} menuFuelSensor_calibration;

//static void menuFuelSensor_calibration_updateDbData(String *db);

static void menuFuelSensor_calibration_job(void)
{
#define MENU_FUELSENSOR_CALIBRATION 3

    String db_menuFuelSensor_calibration[MENU_FUELSENSOR_CALIBRATION]=
    {
        str_clearPrint("1]SET FULL SCALE", 0),
        str_clearPrint("2]SET ZERO", 0),
        str_clearPrint("3]LENGTH TANK DEPTH", 0),
    };

    if (menuFuelSensor_calibration.sm0 == 0)
    {
        kb_stackPush();
        kb_change_keyDo_pgm(menuFuelSensor_calibration_fxKey);

        VS_menuFuelSensor_calibration.init(db_menuFuelSensor_calibration, MENU_FUELSENSOR_CALIBRATION, dispShowBuff, 3, FEAT_MARK_ON);

        menuFuelSensor_calibration.sm0++;
    }

    if (menuFuelSensor_calibration.sm0 == 1)//la opcion de marcado conservarla
    {
        //VS_menuFuelSensor_calibration.init(db_menuFuelSensor_calibration, MENU_FUELSENSOR_CALIBRATION, dispShowBuff, 3, FEAT_MARK_ON);

        sysPrint_lcdPrintPSTR(0, 0, PSTR("[CALIBRATION]"));

        menuFuelSensor_calibration.sm0 = -1;
    }

    VS_menuFuelSensor_calibration.set_db(db_menuFuelSensor_calibration);
    VS_menuFuelSensor_calibration.job();
    lcd_show_disp();
}

////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////

struct _menuFuelSensor_lengthTankDepth_FullZeroCalibration
{
    int sm0;
    int sm1;
    int sm2;
} menuFuelSensor_lengthTankDepth_FullZeroCalibration;

inline static void menuFuelSensor_lengthTankDepth_FullZeroCalibration_escape(void)
{
    //__
    taskman_fuelSensor.sm2 = 0;
    menuFuelSensor_calibration.sm0 = 1;
    kb_stackPop();
    //__
}

static void menuFuelSensor_lengthTankDepth_FullZeroCalibration_fxKey0(void)
{


    if (menuFuelSensor_lengthTankDepth_FullZeroCalibration.sm0 == 1)
    {
        menuFuelSensor_lengthTankDepth_FullZeroCalibration.sm1 = 0;
        menuFuelSensor_lengthTankDepth_FullZeroCalibration.sm0++;
    }
    else if (menuFuelSensor_lengthTankDepth_FullZeroCalibration.sm0 == 2)
    {
        //menuFuelSensor_lengthTankDepth_FullZeroCalibration.sm1 = 0;
        //menuFuelSensor_lengthTankDepth_FullZeroCalibration.sm0++;
    }
    else if (menuFuelSensor_lengthTankDepth_FullZeroCalibration.sm0 == 3)
    {
        //
        //menuFuelSensor_lengthTankDepth_FullZeroCalibration.sm0++;
    }
    else if (menuFuelSensor_lengthTankDepth_FullZeroCalibration.sm0 == 4)
    {
        menuFuelSensor_lengthTankDepth_FullZeroCalibration_escape();

    }
    else if (menuFuelSensor_lengthTankDepth_FullZeroCalibration.sm0 == 5)
    {
        menuFuelSensor_lengthTankDepth_FullZeroCalibration.sm1 = 0;
        menuFuelSensor_lengthTankDepth_FullZeroCalibration.sm0++;
    }
    else if (menuFuelSensor_lengthTankDepth_FullZeroCalibration.sm0 == 6)
    {
        //menuFuelSensor_lengthTankDepth_FullZeroCalibration.sm0++;
    }
}
static void menuFuelSensor_lengthTankDepth_FullZeroCalibration_fxKey1(void)
{
    if (menuFuelSensor_lengthTankDepth_FullZeroCalibration.sm0 == 1)
    {
        menuFuelSensor_lengthTankDepth_FullZeroCalibration.sm1 = 0;
        menuFuelSensor_lengthTankDepth_FullZeroCalibration.sm0++;
    }
    else if (menuFuelSensor_lengthTankDepth_FullZeroCalibration.sm0 == 2)
    {
        //menuFuelSensor_lengthTankDepth_FullZeroCalibration.sm1 = 0;
        //menuFuelSensor_lengthTankDepth_FullZeroCalibration.sm0++;
    }
    else if (menuFuelSensor_lengthTankDepth_FullZeroCalibration.sm0 == 3)
    {
        //menuFuelSensor_lengthTankDepth_FullZeroCalibration.sm0++;
    }
    else if (menuFuelSensor_lengthTankDepth_FullZeroCalibration.sm0 == 4)
    {
        menuFuelSensor_lengthTankDepth_FullZeroCalibration_escape();

    }
    else if (menuFuelSensor_lengthTankDepth_FullZeroCalibration.sm0 == 5)
    {
        menuFuelSensor_lengthTankDepth_FullZeroCalibration.sm1 = 0;
        menuFuelSensor_lengthTankDepth_FullZeroCalibration.sm0++;
    }
    else if (menuFuelSensor_lengthTankDepth_FullZeroCalibration.sm0 == 6)
    {

        vscroll.sign_up();
    }

}
static void menuFuelSensor_lengthTankDepth_FullZeroCalibration_fxKey2(void)
{


    if (menuFuelSensor_lengthTankDepth_FullZeroCalibration.sm0 == 1)
    {
        menuFuelSensor_lengthTankDepth_FullZeroCalibration.sm1 = 0;
        menuFuelSensor_lengthTankDepth_FullZeroCalibration.sm0++;
    }
    else if (menuFuelSensor_lengthTankDepth_FullZeroCalibration.sm0 == 2)
    {
        //menuFuelSensor_lengthTankDepth_FullZeroCalibration.sm0++;
    }
    else if (menuFuelSensor_lengthTankDepth_FullZeroCalibration.sm0 == 3)
    {
        //menuFuelSensor_lengthTankDepth_FullZeroCalibration.sm0++;
    }
    else if (menuFuelSensor_lengthTankDepth_FullZeroCalibration.sm0 == 4)
    {
        menuFuelSensor_lengthTankDepth_FullZeroCalibration_escape();

    }
    else if (menuFuelSensor_lengthTankDepth_FullZeroCalibration.sm0 == 5)
    {
        menuFuelSensor_lengthTankDepth_FullZeroCalibration.sm1 = 0;
        menuFuelSensor_lengthTankDepth_FullZeroCalibration.sm0++;
    }
    else if (menuFuelSensor_lengthTankDepth_FullZeroCalibration.sm0 == 6)
    {
        vscroll.sign_down();
    }
}
static void menuFuelSensor_lengthTankDepth_FullZeroCalibration_fxKey3(void)
{
    uint8_t opt = vscroll.get_markPosc();

    if (menuFuelSensor_lengthTankDepth_FullZeroCalibration.sm0 == 1)//attention
    {
        menuFuelSensor_lengthTankDepth_FullZeroCalibration.sm1 = 0;
        menuFuelSensor_lengthTankDepth_FullZeroCalibration.sm0++;
    }
    else if (menuFuelSensor_lengthTankDepth_FullZeroCalibration.sm0 == 2)//waiting
    {
        menuFuelSensor_lengthTankDepth_FullZeroCalibration.sm1 = 0;
        menuFuelSensor_lengthTankDepth_FullZeroCalibration.sm0++;
    }
    else if (menuFuelSensor_lengthTankDepth_FullZeroCalibration.sm0 == 3)//do calib
    {
        menuFuelSensor_lengthTankDepth_FullZeroCalibration.sm2 =1;
    }
    else if (menuFuelSensor_lengthTankDepth_FullZeroCalibration.sm0 == 4)//success.
    {
        menuFuelSensor_lengthTankDepth_FullZeroCalibration_escape();
    }
    else if (menuFuelSensor_lengthTankDepth_FullZeroCalibration.sm0 == 5)
    {
        menuFuelSensor_lengthTankDepth_FullZeroCalibration.sm1 = 0;
        menuFuelSensor_lengthTankDepth_FullZeroCalibration.sm0++;
    }
    else if (menuFuelSensor_lengthTankDepth_FullZeroCalibration.sm0 == 6)
    {
        if (opt == 0)
        {
            //retry

            menuFuelSensor_lengthTankDepth_FullZeroCalibration.sm0 = 2;
            menuFuelSensor_lengthTankDepth_FullZeroCalibration.sm1 = 0;
        }
        else
        {
            //escape
            menuFuelSensor_lengthTankDepth_FullZeroCalibration_escape();
        }
    }

}
static void menuFuelSensor_lengthTankDepth_FullZeroCalibration_fxKey4(void)
{
    menuFuelSensor_lengthTankDepth_FullZeroCalibration.sm1 = 0;

    if (menuFuelSensor_lengthTankDepth_FullZeroCalibration.sm0 == 1)
    {
        menuFuelSensor_lengthTankDepth_FullZeroCalibration.sm0++;
    }
    else if (menuFuelSensor_lengthTankDepth_FullZeroCalibration.sm0 == 2)
    {
        menuFuelSensor_lengthTankDepth_FullZeroCalibration.sm0++;
    }
    else if (menuFuelSensor_lengthTankDepth_FullZeroCalibration.sm0 == 3)
    {
        menuFuelSensor_lengthTankDepth_FullZeroCalibration.sm0++;
    }
    else if (menuFuelSensor_lengthTankDepth_FullZeroCalibration.sm0 == 4)
    {
        menuFuelSensor_lengthTankDepth_FullZeroCalibration_escape();
    }
    else if (menuFuelSensor_lengthTankDepth_FullZeroCalibration.sm0 == 5)
    {
        menuFuelSensor_lengthTankDepth_FullZeroCalibration.sm1 = 0;
        menuFuelSensor_lengthTankDepth_FullZeroCalibration.sm0++;
    }
    else if (menuFuelSensor_lengthTankDepth_FullZeroCalibration.sm0 == 6)
    {
        //menuFuelSensor_lengthTankDepth_FullZeroCalibration.sm0++;
    }
}

PTRFX_retVOID const menuFuelSensor_lengthTankDepth_FullZeroCalibration_fxKey[KB_NUM_KEYS] PROGMEM =
{
    menuFuelSensor_lengthTankDepth_FullZeroCalibration_fxKey0, menuFuelSensor_lengthTankDepth_FullZeroCalibration_fxKey1, menuFuelSensor_lengthTankDepth_FullZeroCalibration_fxKey2,
    menuFuelSensor_lengthTankDepth_FullZeroCalibration_fxKey3, menuFuelSensor_lengthTankDepth_FullZeroCalibration_fxKey4
};

static void menuFuelSensor_lengthTankDepth_FullZeroCalibration_job(void)
{
    String msg;

    if (menuFuelSensor_lengthTankDepth_FullZeroCalibration.sm0 == 0)
    {
        kb_stackPush();
        kb_change_keyDo_pgm(menuFuelSensor_lengthTankDepth_FullZeroCalibration_fxKey);

        menuFuelSensor_lengthTankDepth_FullZeroCalibration.sm1 = 0;
        menuFuelSensor_lengthTankDepth_FullZeroCalibration.sm2 = 0;

        menuFuelSensor_lengthTankDepth_FullZeroCalibration.sm0++;
    }

    if (menuFuelSensor_lengthTankDepth_FullZeroCalibration.sm0 == 1)
    {
        if (menuFuelSensor_lengthTankDepth_FullZeroCalibration.sm1 == 0)
        {
            lcd.clear();

            //sysPrint_lcdPrintPSTR(LCD_ROW_0, STR_CENTER, "[ATTENTION]");
            sysPrint_lcdPrintPSTR(LCD_ROW_0, STR_CENTER, PSTR("[ATTENTION]"));

            sysPrint_lcdPrintPSTR(LCD_ROW_1, STR_CENTER, PSTR("You have to do Full"));
            sysPrint_lcdPrintPSTR(LCD_ROW_2, STR_CENTER, PSTR("calibration firstly,"));
            sysPrint_lcdPrintPSTR(LCD_ROW_3, STR_CENTER, PSTR("then Zero calib..."));

            menuFuelSensor_lengthTankDepth_FullZeroCalibration.sm1 = -1;
        }
    }

    if (menuFuelSensor_lengthTankDepth_FullZeroCalibration.sm0 == 2)
    {
        if (menuFuelSensor_lengthTankDepth_FullZeroCalibration.sm1 == 0)
        {
            lcd.clear();

            sysPrint_lcdPrintPSTR(LCD_ROW_0, STR_CENTER, PSTR("[MESSAGE]"));
            sysPrint_lcdPrintPSTR(LCD_ROW_1, STR_CENTER, PSTR("Press key <Enter> to"));
            msg = "begin ";
            if (fuelsensor.calib.bf.do_fullzero == FS_DO_FULL_CALIB)
                msg+= "Full";
            else
                msg+= "Zero";
            sysPrint_lcdPrint(LCD_ROW_2, STR_CENTER, msg);
            sysPrint_lcdPrintPSTR(LCD_ROW_3, STR_CENTER, PSTR("calibration...."));


            menuFuelSensor_lengthTankDepth_FullZeroCalibration.sm1 = -1;
        }
    }

    if (menuFuelSensor_lengthTankDepth_FullZeroCalibration.sm0 == 3)
    {
        if (menuFuelSensor_lengthTankDepth_FullZeroCalibration.sm1 == 0)
        {
            lcd.clear();

            sysPrint_lcdPrintPSTR(LCD_ROW_0, STR_CENTER, PSTR("[MESSAGE]"));
            sysPrint_lcdPrintPSTR(LCD_ROW_1, STR_CENTER, PSTR("Doing calibration"));
            sysPrint_lcdPrintPSTR(LCD_ROW_2, STR_CENTER, PSTR("...."));

            menuFuelSensor_lengthTankDepth_FullZeroCalibration.sm1 = -1;
        }

        // if (fuelsensor.calib.bf.do_fullzero == FS_DO_FULL_CALIB)
        // {
        // }
        // else
        // {

        // }
        if (menuFuelSensor_lengthTankDepth_FullZeroCalibration.sm2 == 1)
        {
            menuFuelSensor_lengthTankDepth_FullZeroCalibration.sm1 = 0;
            menuFuelSensor_lengthTankDepth_FullZeroCalibration.sm0++;
            //
            menuFuelSensor_lengthTankDepth_FullZeroCalibration.sm0++;
        }

    }

    if (menuFuelSensor_lengthTankDepth_FullZeroCalibration.sm0 == 4)
    {
        if (menuFuelSensor_lengthTankDepth_FullZeroCalibration.sm1 == 0)
        {
            lcd.clear();
            sysPrint_lcdPrintPSTR(LCD_ROW_0, STR_CENTER, PSTR("[MESSAGE]"));
            sysPrint_lcdPrintPSTR(LCD_ROW_1, STR_CENTER, PSTR("Calibration was"));
            sysPrint_lcdPrintPSTR(LCD_ROW_2, STR_CENTER, PSTR("successfully!"));
            sysPrint_lcdPrintPSTR(LCD_ROW_3, STR_CENTER, PSTR("(Press any key...)"));

            menuFuelSensor_lengthTankDepth_FullZeroCalibration.sm1 = -1;
        }
    }
    if (menuFuelSensor_lengthTankDepth_FullZeroCalibration.sm0 == 5)
    {
        if (menuFuelSensor_lengthTankDepth_FullZeroCalibration.sm1 == 0)
        {
            lcd.clear();
            sysPrint_lcdPrintPSTR(LCD_ROW_0, STR_CENTER, PSTR("[ERROR]"));
            sysPrint_lcdPrintPSTR(LCD_ROW_1, STR_CENTER, PSTR("Calibration failed!"));
            sysPrint_lcdPrintPSTR(LCD_ROW_2, STR_CENTER, PSTR("Sensor need to be"));
            sysPrint_lcdPrintPSTR(LCD_ROW_3, STR_CENTER, PSTR("re-calibrated!"));

            menuFuelSensor_lengthTankDepth_FullZeroCalibration.sm1 = -1;
        }
    }
    if (menuFuelSensor_lengthTankDepth_FullZeroCalibration.sm0 == 6)
    {
        String db_vscroll[2] =
        {
            str_clearPrint("1] Yes", 7),
            str_clearPrint("2] No", 7),
        };

        if (menuFuelSensor_lengthTankDepth_FullZeroCalibration.sm1 == 0)
        {
            lcd.clear();
            sysPrint_lcdPrintPSTR(LCD_ROW_0, STR_CENTER, PSTR("[MESSAGE]"));
            sysPrint_lcdPrintPSTR(LCD_ROW_1, STR_CENTER, PSTR("Retry calibration?"));

            vscroll.init(db_vscroll, 2, dispShowBuff, 2, FEAT_MARK_ON);

            menuFuelSensor_lengthTankDepth_FullZeroCalibration.sm1 = -1;
        }

        vscroll.set_db(db_vscroll);
        vscroll.job();
        lcd_show_disp(LCD_ROW_2);
    }

}
////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////
#define PARAM_STR_LENGTH (6+1)//6+\0
#define PARAM_STR_DIG_POS_DP 3
#define PARAM_STR_DIG_POS_MAX (PARAM_STR_LENGTH-2)

#define PARAM_STR_DP_PRECISION 2

struct _menuFuelSensor_lengthTankDepth
{
    int sm0;
    //int sm1;
} menuFuelSensor_lengthTankDepth;

#define SETNUM_PARAM_INNERTANK 0
#define SETNUM_PARAM_ZERO2FULL  1
#define SETNUM_PARAM_FULL2UPPER 2

static void lengthTankDepth_setnum_digit_blink_print(uint8_t blink_toggle, uint8_t setnum_digit_position );
inline static void setnum_digit_blink_set2blank(void);
inline static void setnum_digit_blink_set2noblank(void);

static void lengthTankDepth_setnum_check_boundary(void);

static inline void menuFuelSensor_lengthTankDepth_fxKey0(void)
{
}
static inline void menuFuelSensor_lengthTankDepth_fxKey1(void)
{
    char *PARAMstr;

    if (setnum.param == SETNUM_PARAM_INNERTANK)
        PARAMstr = PARAM0str;
    else if (setnum.param == SETNUM_PARAM_ZERO2FULL)
        PARAMstr = PARAM1str;
    else if (setnum.param == SETNUM_PARAM_FULL2UPPER)
        PARAMstr = PARAM2str;

    if (--PARAMstr[setnum.digit.position]< '0')
        PARAMstr[setnum.digit.position] = '9';

    setnum_digit_blink_set2noblank();
}

static inline void menuFuelSensor_lengthTankDepth_fxKey2(void)
{
    char *PARAMstr;

    if (setnum.param == SETNUM_PARAM_INNERTANK)
        PARAMstr = PARAM0str;
    else if (setnum.param == SETNUM_PARAM_ZERO2FULL)
        PARAMstr = PARAM1str;
    else if (setnum.param == SETNUM_PARAM_FULL2UPPER)
        PARAMstr = PARAM2str;

    if (++PARAMstr[setnum.digit.position] > '9')
        PARAMstr[setnum.digit.position] = '0';

    setnum_digit_blink_set2noblank();
}

static inline void menuFuelSensor_lengthTankDepth_fxKey3(void)
{
    lengthTankDepth_setnum_check_boundary();

    lengthTankDepth_setnum_digit_blink_print(BLINK_TOGGLE_NOBLANK, setnum.digit.position);//fix latest digit before to leave

    setnum.digit.position++;

    if (setnum.digit.position == PARAM_STR_DIG_POS_DP)//skip decimal point
        setnum.digit.position++;

    if (setnum.digit.position > PARAM_STR_DIG_POS_MAX)//
    {
        //lengthTankDepth_setnum_digit_blink_print(BLINK_TOGGLE_NOBLANK, PARAM_STR_DIG_POS_MAX);//fix latest digit before to leave

        setnum.digit.position = 0;

        if (++setnum.param == 3)
            setnum.param = 0;

        //help title
        if (setnum.param == 0)
            sysPrint_lcdPrintPSTR(0, 0, PSTR("[D1 in cm]"));
        else if (setnum.param == 1)
            sysPrint_lcdPrintPSTR(0, 0, PSTR("[D2 in cm]"));
        else if (setnum.param == 2)
            sysPrint_lcdPrintPSTR(0, 0, PSTR("[D3 in cm]"));
        //
    }

    setnum_digit_blink_set2blank();
}

static inline void menuFuelSensor_lengthTankDepth_fxKey4(void)
{
    fuelsensor.calib.tank.innertank = strtod(PARAM0str, (char**)0);
    fuelsensor.calib.tank.zero2full = strtod(PARAM1str, (char**)0);
    fuelsensor.calib.tank.full2upper =strtod(PARAM2str, (char**)0);

    taskman_fuelSensor.sign = TASKMAN_SIGN_ENTER;

    if ( (fuelsensor.calib.tank.innertank == 0.0f) || (fuelsensor.calib.tank.zero2full == 0.0f) )
    {
        taskman_fuelSensor.sm3 = 1;
    }
    else
    {
        taskman_fuelSensor.sm3 = 2;

    }
}

PTRFX_retVOID const menuFuelSensor_lengthTankDepth_fxKey[KB_NUM_KEYS] PROGMEM =
{
    menuFuelSensor_lengthTankDepth_fxKey0, menuFuelSensor_lengthTankDepth_fxKey1, menuFuelSensor_lengthTankDepth_fxKey2,
    menuFuelSensor_lengthTankDepth_fxKey3, menuFuelSensor_lengthTankDepth_fxKey4
};

static void print_PARAM0(float f);
static void print_PARAM1(float f);
static void print_PARAM2(float f);

static void menuFuelSensor_lengthTankDepth_job(void)
{
    if (menuFuelSensor_lengthTankDepth.sm0 == 0)
    {
        kb_stackPush();
        kb_change_keyDo_pgm(menuFuelSensor_lengthTankDepth_fxKey);

        menuFuelSensor_lengthTankDepth.sm0++;
    }

    if (menuFuelSensor_lengthTankDepth.sm0 == 1)
    {
        lcd.clear();
        sysPrint_lcdPrintPSTR(0, 0, PSTR("[D1 in cm]"));
        sysPrint_lcdPrintPSTR(1, 0, PSTR("Inner Tank ="));//[HEIGHTS IN CM]
        sysPrint_lcdPrintPSTR(2, 0, PSTR("Zero->Full ="));//[EFFEC.LEN.SCAL.CAL]
        sysPrint_lcdPrintPSTR(3, 0, PSTR("Full->Upper="));//[LEN.TO UPPER SURF.]

        print_PARAM0(fuelsensor.calib.tank.innertank);
        print_PARAM1(fuelsensor.calib.tank.zero2full);
        print_PARAM2(fuelsensor.calib.tank.full2upper);
        //
        setnum.digit.position = 0;
        setnum.param = 0;
        //
        menuFuelSensor_lengthTankDepth.sm0 = -1;
    }

    //-------- blinking ----------
    if (setnum.digit.blink.sm0 == 0)
    {
        if ( (millis() - setnum.digit.blink.last_millis) > 500)
        {
            setnum.digit.blink.bf.toggle = !setnum.digit.blink.bf.toggle;
            setnum.digit.blink.sm0++;
        }
    }
    if (setnum.digit.blink.sm0 == 1)
    {
        lengthTankDepth_setnum_digit_blink_print(setnum.digit.blink.bf.toggle, setnum.digit.position);
        //
        setnum.digit.blink.last_millis = millis();
        setnum.digit.blink.sm0 = 0;
    }
}

static void print_PARAM0(float f)
{
    dtostrf(f, PARAM_STR_LENGTH-DTOSTRF_SIGN_POS, PARAM_STR_DP_PRECISION, PARAM0str);
    dtostrf_fill_zero(PARAM0str);
    lcd.printAtPosc(LCD_ROW_1,13, String(PARAM0str));
}
static void print_PARAM1(float f)
{
    dtostrf(f, PARAM_STR_LENGTH-DTOSTRF_SIGN_POS, PARAM_STR_DP_PRECISION, PARAM1str);
    dtostrf_fill_zero(PARAM1str);
    lcd.printAtPosc(LCD_ROW_2,13, String(PARAM1str));
}
static void print_PARAM2(float f)
{
    dtostrf(f, PARAM_STR_LENGTH-DTOSTRF_SIGN_POS, PARAM_STR_DP_PRECISION, PARAM2str);
    dtostrf_fill_zero(PARAM2str);
    lcd.printAtPosc(LCD_ROW_3,13, String(PARAM2str));
}

/*
inline static void setnum_digit_blink_set2blank(void)
{
    setnum.digit.blink.sm0 = 1;
    setnum.digit.blink.bf.toggle = BLINK_TOGGLE_BLANK;
}

inline static void setnum_digit_blink_set2noblank(void)
{
    setnum.digit.blink.sm0 = 1;
    setnum.digit.blink.bf.toggle = BLINK_TOGGLE_NOBLANK;
}
*/
static void lengthTankDepth_setnum_digit_blink_print(uint8_t blink_toggle, uint8_t setnum_digit_position )
{
    uint8_t col, fil;
    char param_digit_str=' ';
    char *PARAMstr;

    col=13;
    if (setnum.param == SETNUM_PARAM_INNERTANK)
    {
        fil=1;
        PARAMstr = PARAM0str;
    }
    else if (setnum.param == SETNUM_PARAM_ZERO2FULL)
    {
        fil=2;
        PARAMstr = PARAM1str;
    }
    else if (setnum.param == SETNUM_PARAM_FULL2UPPER)
    {
        fil=3;
        PARAMstr = PARAM2str;
    }

    if (blink_toggle == BLINK_TOGGLE_NOBLANK)
        param_digit_str = PARAMstr[setnum_digit_position];

    col += setnum_digit_position;
    lcd.printAtPosc(fil, col,String(param_digit_str));
}

static void lengthTankDepth_setnum_check_boundary(void)
{
    float d1,d2,d3;
    //float limit;

    d1 = strtod(PARAM0str, (char**)0);

    //check for d2
    d2 = strtod(PARAM1str, (char**)0);

    if (d2> d1)
    {
        d2= d1;
        print_PARAM1(d2);
    }

    //check for d3
    d3 = strtod(PARAM2str, (char**)0);

    if ( (d2+d3) > d1)
    {
        d3 = d1-d2;
        print_PARAM2(d3);
    }
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////
struct _menuFuelSensor_lengthTankDepth_errorConsistency
{
    int sm0;
    int sm1;

} menuFuelSensor_lengthTankDepth_errorConsistency;

static void menuFuelSensor_lengthTankDepth_returnToItsCaller(void)
{
    menuFuelSensor_calibration.sm0 = 1;
    taskman_fuelSensor.sm2 = 0;
    kb_stackPop();
    kb_stackPop();
}

static void menuFuelSensor_lengthTankDepth_errorConsistency_fxKey0(void)
{
    if (menuFuelSensor_lengthTankDepth_errorConsistency.sm1 == 0)
    {
        menuFuelSensor_lengthTankDepth_errorConsistency.sm1++;//skip the error
        menuFuelSensor_lengthTankDepth_errorConsistency.sm0 = 1;
    }
    else if (menuFuelSensor_lengthTankDepth_errorConsistency.sm1 == 1)
    {
    }
    else if (menuFuelSensor_lengthTankDepth_errorConsistency.sm1 == 2)
    {
        menuFuelSensor_lengthTankDepth_returnToItsCaller();
    }
}
static void menuFuelSensor_lengthTankDepth_errorConsistency_fxKey1(void)
{
    if (menuFuelSensor_lengthTankDepth_errorConsistency.sm1 == 0)
    {
        menuFuelSensor_lengthTankDepth_errorConsistency.sm1++;//skip the error
        menuFuelSensor_lengthTankDepth_errorConsistency.sm0 = 1;
    }
    else if (menuFuelSensor_lengthTankDepth_errorConsistency.sm1 == 1)
    {
        vscroll.sign_up();
    }
    else if (menuFuelSensor_lengthTankDepth_errorConsistency.sm1 == 2)
    {
        menuFuelSensor_lengthTankDepth_returnToItsCaller();
    }
}
static void menuFuelSensor_lengthTankDepth_errorConsistency_fxKey2(void)
{
    if (menuFuelSensor_lengthTankDepth_errorConsistency.sm1 == 0)
    {
        menuFuelSensor_lengthTankDepth_errorConsistency.sm1++;//skip the error
        menuFuelSensor_lengthTankDepth_errorConsistency.sm0 = 1;
    }
    else if (menuFuelSensor_lengthTankDepth_errorConsistency.sm1 == 1)
    {
        vscroll.sign_down();
    }
    else if (menuFuelSensor_lengthTankDepth_errorConsistency.sm1 == 2)
    {
        menuFuelSensor_lengthTankDepth_returnToItsCaller();
    }
}
static void menuFuelSensor_lengthTankDepth_errorConsistency_fxKey3(void)
{
    if (menuFuelSensor_lengthTankDepth_errorConsistency.sm1 == 0)
    {
        menuFuelSensor_lengthTankDepth_errorConsistency.sm1++;//skip the error
        menuFuelSensor_lengthTankDepth_errorConsistency.sm0 = 1;
    }
    else if (menuFuelSensor_lengthTankDepth_errorConsistency.sm1 == 1)
    {
        uint8_t posc = vscroll.get_markPosc();

        if (posc == 0)
        {
            taskman_fuelSensor.sm3 = 0;
            menuFuelSensor_lengthTankDepth.sm0 = 1;
            kb_stackPop();
        }
        else
        {
            menuFuelSensor_lengthTankDepth_errorConsistency.sm0 = 1;
            menuFuelSensor_lengthTankDepth_errorConsistency.sm1++;
        }
    }
    else if (menuFuelSensor_lengthTankDepth_errorConsistency.sm1 == 2)
    {
        menuFuelSensor_lengthTankDepth_returnToItsCaller();
    }
}

static void menuFuelSensor_lengthTankDepth_errorConsistency_fxKey4(void)
{
    if (menuFuelSensor_lengthTankDepth_errorConsistency.sm1 == 0)
    {
        menuFuelSensor_lengthTankDepth_errorConsistency.sm1++;//skip the error
        menuFuelSensor_lengthTankDepth_errorConsistency.sm0 = 1;
    }
    else if (menuFuelSensor_lengthTankDepth_errorConsistency.sm1 == 1)
    {

    }
    else if (menuFuelSensor_lengthTankDepth_errorConsistency.sm1 == 2)
    {
        menuFuelSensor_lengthTankDepth_returnToItsCaller();
    }
}

PTRFX_retVOID const menuFuelSensor_lengthTankDepth_errorConsistency_fxKey[KB_NUM_KEYS] PROGMEM =
{
    menuFuelSensor_lengthTankDepth_errorConsistency_fxKey0, menuFuelSensor_lengthTankDepth_errorConsistency_fxKey1, menuFuelSensor_lengthTankDepth_errorConsistency_fxKey2,
    menuFuelSensor_lengthTankDepth_errorConsistency_fxKey3, menuFuelSensor_lengthTankDepth_errorConsistency_fxKey4
};

static void menuFuelSensor_lengthTankDepth_errorConsistency_job(void)
{
    if (menuFuelSensor_lengthTankDepth_errorConsistency.sm0 == 0)
    {
        kb_stackPush();
        kb_change_keyDo_pgm(menuFuelSensor_lengthTankDepth_errorConsistency_fxKey);
        //
        menuFuelSensor_lengthTankDepth_errorConsistency.sm1 = 0x00;

        //
        menuFuelSensor_lengthTankDepth_errorConsistency.sm0++;
    }

    if (menuFuelSensor_lengthTankDepth_errorConsistency.sm1 == 0)
    {
        if (menuFuelSensor_lengthTankDepth_errorConsistency.sm0 == 1)
        {
            lcd.clear();
            sysPrint_lcdPrintPSTR(LCD_ROW_0, STR_CENTER, PSTR("[ERROR]"));

            String msg="Length ";

            if (fuelsensor.calib.tank.innertank == 0)
                msg+="[D1] ";

            if (fuelsensor.calib.tank.zero2full == 0)
                msg+="[D2]";

            sysPrint_lcdPrint(LCD_ROW_1, STR_CENTER, msg);
            sysPrint_lcdPrintPSTR(LCD_ROW_2, STR_CENTER, PSTR("must be greater"));
            sysPrint_lcdPrintPSTR(LCD_ROW_3, STR_CENTER, PSTR("than zero"));

            menuFuelSensor_lengthTankDepth_errorConsistency.sm0 = -1;
        }
    }
    else if (menuFuelSensor_lengthTankDepth_errorConsistency.sm1 == 1)
    {
        String db_vscroll[2] =
        {
            str_clearPrint("1] Yes", 7),
            str_clearPrint("2] No", 7),
        };

        if (menuFuelSensor_lengthTankDepth_errorConsistency.sm0 == 1)
        {
            sysPrint_lcdPrintPSTR(LCD_ROW_0, STR_CENTER, PSTR("[DATA INCONSISTENT]"));
            sysPrint_lcdPrintPSTR(LCD_ROW_1, STR_CENTER, PSTR("Fix the errors?"));

            vscroll.init(db_vscroll, 2, dispShowBuff, 2, FEAT_MARK_ON);

            menuFuelSensor_lengthTankDepth_errorConsistency.sm0 = -1;
        }

        vscroll.set_db(db_vscroll);
        vscroll.job();
        lcd_show_disp(LCD_ROW_2);
    }
    else if (menuFuelSensor_lengthTankDepth_errorConsistency.sm1 == 2)
    {
        if (menuFuelSensor_lengthTankDepth_errorConsistency.sm0 == 1)
        {
            sysPrint_lcdPrintPSTR(LCD_ROW_0, STR_CENTER, PSTR("[WARNING]"));
            sysPrint_lcdPrintPSTR(LCD_ROW_1, STR_CENTER, PSTR("Data are wrong"));
            sysPrint_lcdPrintPSTR(LCD_ROW_2, STR_CENTER, PSTR("to get volume"));
            sysPrint_lcdPrintPSTR(LCD_ROW_3, STR_CENTER, PSTR("(Press any key...)"));

            menuFuelSensor_lengthTankDepth_errorConsistency.sm0 = -1;
        }
    }
}

////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////
struct _menuFuelSensor_lengthTankDepth_noErrorConsistency
{
    int sm0;
    int sm1;
} menuFuelSensor_lengthTankDepth_noErrorConsistency;

static void menuFuelSensor_lengthTankDepth_noErrorConsistency_fxKey0(void)
{
}
static void menuFuelSensor_lengthTankDepth_noErrorConsistency_fxKey1(void)
{
    vscroll.sign_up();
}
static void menuFuelSensor_lengthTankDepth_noErrorConsistency_fxKey2(void)
{
    vscroll.sign_down();
}
static void menuFuelSensor_lengthTankDepth_noErrorConsistency_fxKey3(void)
{
    uint8_t posc = vscroll.get_markPosc();

    if (menuFuelSensor_lengthTankDepth_noErrorConsistency.sm0 == 1)
    {
        if (posc == 0)//Yes
        {
            //save data to EEPROM

            fuelsensor.calib.bf.lengthsTankdepth_consistent = 1;

        }
        // else//nothing to do for "NO" option
        // {
        // }

        menuFuelSensor_lengthTankDepth_noErrorConsistency.sm1 = 0;
        menuFuelSensor_lengthTankDepth_noErrorConsistency.sm0++;//next step
    }
    else if (menuFuelSensor_lengthTankDepth_noErrorConsistency.sm0 == 2)
    {
        if (posc == 0)
        {
            menuFuelSensor_lengthTankDepth_returnToItsCaller();
        }
        else
        {
            taskman_fuelSensor.sm3 = 0;
            menuFuelSensor_lengthTankDepth.sm0 = 1;
            kb_stackPop();
        }
    }
}
static void menuFuelSensor_lengthTankDepth_noErrorConsistency_fxKey4(void)
{
}

PTRFX_retVOID const menuFuelSensor_lengthTankDepth_noErrorConsistency_fxKey[KB_NUM_KEYS] PROGMEM =
{
    menuFuelSensor_lengthTankDepth_noErrorConsistency_fxKey0, menuFuelSensor_lengthTankDepth_noErrorConsistency_fxKey1, menuFuelSensor_lengthTankDepth_noErrorConsistency_fxKey2,
    menuFuelSensor_lengthTankDepth_noErrorConsistency_fxKey3, menuFuelSensor_lengthTankDepth_noErrorConsistency_fxKey4
};

static void menuFuelSensor_lengthTankDepth_noErrorConsistency_job(void)
{
    if (menuFuelSensor_lengthTankDepth_noErrorConsistency.sm0 == 0)
    {
        kb_stackPush();
        kb_change_keyDo_pgm(menuFuelSensor_lengthTankDepth_noErrorConsistency_fxKey);

        menuFuelSensor_lengthTankDepth_noErrorConsistency.sm1 = 0;

        menuFuelSensor_lengthTankDepth_noErrorConsistency.sm0++;
    }

    String db_vscroll[2] =
    {
        str_clearPrint("1] Yes", 7),
        str_clearPrint("2] No", 7),
    };

    if (menuFuelSensor_lengthTankDepth_noErrorConsistency.sm0 == 1)
    {
        if (menuFuelSensor_lengthTankDepth_noErrorConsistency.sm1 == 0)
        {
            vscroll.init(db_vscroll, 2, dispShowBuff, 2, FEAT_MARK_ON);

            lcd.clear();
            sysPrint_lcdPrintPSTR(LCD_ROW_0, STR_CENTER, PSTR("[DATA IS CONSISTENT]"));
            sysPrint_lcdPrintPSTR(LCD_ROW_1, STR_CENTER, PSTR("Save data?"));

            menuFuelSensor_lengthTankDepth_noErrorConsistency.sm1 = -1;
        }
    }
    else
    {
        if (menuFuelSensor_lengthTankDepth_noErrorConsistency.sm1 == 0)
        {
            vscroll.init(db_vscroll, 2, dispShowBuff, 2, FEAT_MARK_ON);

            lcd.clear();
            sysPrint_lcdPrintPSTR(LCD_ROW_0, STR_CENTER, PSTR("[MESSAGE]"));
            sysPrint_lcdPrintPSTR(LCD_ROW_1, STR_CENTER, PSTR("Exit ?"));//then EXIT

            menuFuelSensor_lengthTankDepth_noErrorConsistency.sm1 = -1;
        }
    }
    vscroll.set_db(db_vscroll);
    vscroll.job();
    lcd_show_disp(LCD_ROW_2);
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////
//VScroll vscroll;
//__________________________________________________
#define MENU_FUELSENSOR_OUTPUTTYPE 2

const struct _fuelsensor_db_outputType
{
    char name[10];
}
fuelsensor_db_outputType[MENU_FUELSENSOR_OUTPUTTYPE] PROGMEM=
{
    "LENGTH",
    "VOLUME",
};

inline static void fuelsensor_get_outputType_name(uint8_t type, char *buf)
{
    strcpy_P(buf, (char *) &fuelsensor_db_outputType[type].name );
}
//__________________________________________________
//#define fuelsensor_get_outputType_name(type, buf) do{strcpy_P(buf, (char *) &fuelsensor_db_outputType[type].name );}while(0)

static inline void menuFuelSensor_outputType_fxKey0(void)
{
}
static inline void menuFuelSensor_outputType_fxKey1(void)
{
    if (fuelsensor.calib.bf.lengthsTankdepth_consistent)
        vscroll.sign_up();
}
static inline void menuFuelSensor_outputType_fxKey2(void)
{
    if (fuelsensor.calib.bf.lengthsTankdepth_consistent)
        vscroll.sign_down();
}
static inline void menuFuelSensor_outputType_fxKey3(void)
{
    uint8_t posc = vscroll.get_markPosc();

    fuelsensor.outputType.type = (FS_OUTPUTTYPE) posc;

    char buf[10];
    fuelsensor_get_outputType_name(fuelsensor.outputType.type, buf);
    sysPrint_lcdPrint(1, 0, "Current: " + String(buf));

    //
    taskman_fuelSensor.sign = TASKMAN_SIGN_ENTER;
    if (posc == 0)
    {
        taskman_fuelSensor.sm2 = 1;//to units of length
    }
    else if (posc == 1)
        taskman_fuelSensor.sm2 = 2;//to units of volume

}
static inline void menuFuelSensor_outputType_fxKey4(void)
{
    taskman_fuelSensor.sm1 = 0;
    kb_stackPop();
}

PTRFX_retVOID const menuFuelSensor_outputType_fxKey[KB_NUM_KEYS] PROGMEM =
{
    menuFuelSensor_outputType_fxKey0, menuFuelSensor_outputType_fxKey1, menuFuelSensor_outputType_fxKey2,
    menuFuelSensor_outputType_fxKey3, menuFuelSensor_outputType_fxKey4
};

//-----------------------------------------------------------------------------------------------------------
struct _menuFuelSensor_outputType
{
    int8_t sm0;
} menuFuelSensor_outputType;

static void menuFuelSensor_outputType_job(void)
{
    char buf[10];

    String db_menuFuelSensor_outputType[MENU_FUELSENSOR_OUTPUTTYPE];

    for (uint8_t i=0; i<MENU_FUELSENSOR_OUTPUTTYPE; i++)
    {
        fuelsensor_get_outputType_name(i, buf);
        db_menuFuelSensor_outputType[i] = str_clearPrint(String(i+1)+ "] "+ String(buf), 5);
    }

    if (menuFuelSensor_outputType.sm0 == 0)//only at enter
    {
        kb_stackPush();
        kb_change_keyDo_pgm(menuFuelSensor_outputType_fxKey);
        //

        menuFuelSensor_outputType.sm0++;
    }
    if (menuFuelSensor_outputType.sm0 == 1)//return from sub-menu
    {
        vscroll.init(db_menuFuelSensor_outputType, MENU_FUELSENSOR_OUTPUTTYPE, dispShowBuff, 2, FEAT_MARK_ON);
        //
        lcd.clear();
        sysPrint_lcdPrintPSTR(0, 0, PSTR("[OUTPUT TYPE]"));

        fuelsensor_get_outputType_name(fuelsensor.outputType.type, buf);
        sysPrint_lcdPrint(1, 0, "Current: " + String(buf));

        //
        menuFuelSensor_outputType.sm0 = -1;
    }

    vscroll.set_db(db_menuFuelSensor_outputType);
    vscroll.job();
    lcd_show_disp(LCD_ROW_2);
}
////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////
#define MENU_FUELSENSOR_LENGTHUNITS_NUMITEM 3
#define MENU_FUELSENSOR_LENGTHUNITS_LENGTHITEM 11
const struct _fuelsensor_db_lengthUnits
{
    char name[MENU_FUELSENSOR_LENGTHUNITS_LENGTHITEM];
}
fuelsensor_db_lengthUnits[MENU_FUELSENSOR_LENGTHUNITS_NUMITEM] PROGMEM=
{
    "Percentage",
    "Centimeter",
    "Meter",
};

inline static void fuelsensor_get_lengthUnits_name(uint8_t type, char *buf)
{
    strcpy_P(buf, (char *) &fuelsensor_db_lengthUnits[type].name );
}

static inline void menuFuelSensor_lengthUnits_fxKey0(void)
{
}
static inline void menuFuelSensor_lengthUnits_fxKey1(void)
{
    if (fuelsensor.calib.bf.lengthsTankdepth_consistent)
    {
        vscroll.sign_up();
    }
}
static inline void menuFuelSensor_lengthUnits_fxKey2(void)
{
    if (fuelsensor.calib.bf.lengthsTankdepth_consistent)
    {
        vscroll.sign_down();
    }
}
static inline void menuFuelSensor_lengthUnits_fxKey3(void)
{
    if (fuelsensor.calib.bf.lengthsTankdepth_consistent)
    {
        uint8_t posc = vscroll.get_markPosc();

        fuelsensor.outputType.units = posc;

        char buf[10];
        fuelsensor_get_lengthUnits_name(fuelsensor.outputType.units, buf);
        sysPrint_lcdPrint(1, 0, "Current: " + String(buf));
    }
}
static inline void menuFuelSensor_lengthUnits_fxKey4(void)
{
    taskman_fuelSensor.sm2 = 0;//return to top level
    menuFuelSensor_outputType.sm0 = 1;//menu anterior

    kb_stackPop();
}

PTRFX_retVOID const menuFuelSensor_lengthUnits_fxKey[KB_NUM_KEYS] PROGMEM =
{
    menuFuelSensor_lengthUnits_fxKey0, menuFuelSensor_lengthUnits_fxKey1, menuFuelSensor_lengthUnits_fxKey2,
    menuFuelSensor_lengthUnits_fxKey3, menuFuelSensor_lengthUnits_fxKey4
};

//-----------------------------------------------------------------------------------------------------------
struct _menuFuelSensor_lengthUnits
{
    int8_t sm0;
} menuFuelSensor_lengthUnits;

static void menuFuelSensor_lengthUnits_job(void)
{
    char buf[MENU_FUELSENSOR_LENGTHUNITS_LENGTHITEM];

    String db_menuFuelSensor_lengthUnits[MENU_FUELSENSOR_LENGTHUNITS_NUMITEM];

    for (uint8_t i=0; i<MENU_FUELSENSOR_LENGTHUNITS_NUMITEM; i++)
    {
        fuelsensor_get_lengthUnits_name(i, buf);
        db_menuFuelSensor_lengthUnits[i] = str_clearPrint(String(i+1)+ "] "+ String(buf), 2);
    }

    if (menuFuelSensor_lengthUnits.sm0 == 0)
    {
        kb_stackPush();
        kb_change_keyDo_pgm(menuFuelSensor_lengthUnits_fxKey);

        menuFuelSensor_lengthUnits.sm0++;
    }

    if (menuFuelSensor_lengthUnits.sm0 == 1)
    {
        vscroll.init(db_menuFuelSensor_lengthUnits, MENU_FUELSENSOR_LENGTHUNITS_NUMITEM, dispShowBuff, 2, FEAT_MARK_ON);

        lcd.clear();
        sysPrint_lcdPrintPSTR(0, 0, PSTR("[UNITS OF LENGTH]"));

        fuelsensor.outputType.units= 0;

        if (fuelsensor.calib.bf.lengthsTankdepth_consistent)
        {

        }
        else
        {
            //only percentage
//            fuelsensor.outputType.units = 0;
        }

        fuelsensor_get_lengthUnits_name(fuelsensor.outputType.units, buf);
        sysPrint_lcdPrint(1, 0, "Current: " + String(buf));

        //
        menuFuelSensor_lengthUnits.sm0 = -1;
    }

    vscroll.set_db(db_menuFuelSensor_lengthUnits);
    vscroll.job();
    lcd_show_disp(LCD_ROW_2);
}
////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////
#define MENU_FUELSENSOR_VOLUMEUNITS_NUMITEM 2
#define MENU_FUELSENSOR_VOLUMEUNITS_LENGTHITEM 8
const struct _fuelsensor_db_volumenUnits
{
    char name[MENU_FUELSENSOR_VOLUMEUNITS_LENGTHITEM];
}
fuelsensor_db_volumenUnits[MENU_FUELSENSOR_VOLUMEUNITS_NUMITEM] PROGMEM=
{
    "Gallons",
    "Liters",
};

inline static void fuelsensor_get_volumenUnits_name(uint8_t type, char *buf)
{
    strcpy_P(buf, (char *) &fuelsensor_db_volumenUnits[type].name );
}

static inline void menuFuelSensor_volumenUnits_fxKey0(void)
{
}
static inline void menuFuelSensor_volumenUnits_fxKey1(void)
{
    vscroll.sign_up();

}
static inline void menuFuelSensor_volumenUnits_fxKey2(void)
{
    vscroll.sign_down();
}
static inline void menuFuelSensor_volumenUnits_fxKey3(void)
{
    uint8_t posc = vscroll.get_markPosc();

    fuelsensor.outputType.units = posc;

    char buf[10];
    fuelsensor_get_volumenUnits_name(fuelsensor.outputType.units, buf);
    sysPrint_lcdPrint(1, 0, "Current: " + String(buf));
}
static inline void menuFuelSensor_volumenUnits_fxKey4(void)
{
    taskman_fuelSensor.sm2 = 0;//return to top level
    menuFuelSensor_outputType.sm0 = 1;//menu anterior

    kb_stackPop();
}

PTRFX_retVOID const menuFuelSensor_volumenUnits_fxKey[KB_NUM_KEYS] PROGMEM =
{
    menuFuelSensor_volumenUnits_fxKey0, menuFuelSensor_volumenUnits_fxKey1, menuFuelSensor_volumenUnits_fxKey2,
    menuFuelSensor_volumenUnits_fxKey3, menuFuelSensor_volumenUnits_fxKey4
};

//-----------------------------------------------------------------------------------------------------------
struct _menuFuelSensor_volumenUnits
{
    int8_t sm0;
} menuFuelSensor_volumenUnits;

static void menuFuelSensor_volumenUnits_job(void)
{
    char buf[MENU_FUELSENSOR_VOLUMEUNITS_LENGTHITEM];

    String db_menuFuelSensor_volumenUnits[MENU_FUELSENSOR_VOLUMEUNITS_NUMITEM];

    for (uint8_t i=0; i<MENU_FUELSENSOR_VOLUMEUNITS_NUMITEM; i++)
    {
        fuelsensor_get_volumenUnits_name(i, buf);
        db_menuFuelSensor_volumenUnits[i] = str_clearPrint(String(i+1)+ "] "+ String(buf), 2);
    }

    if (menuFuelSensor_volumenUnits.sm0 == 0)
    {
        kb_stackPush();
        kb_change_keyDo_pgm(menuFuelSensor_volumenUnits_fxKey);


        menuFuelSensor_volumenUnits.sm0++;
    }

    if (menuFuelSensor_volumenUnits.sm0 == 1)
    {
        //
        vscroll.init(db_menuFuelSensor_volumenUnits, MENU_FUELSENSOR_VOLUMEUNITS_NUMITEM, dispShowBuff, 2, FEAT_MARK_ON);
        //
        lcd.clear();
        sysPrint_lcdPrintPSTR(0, 0, PSTR("[UNITS OF VOLUME]"));

        fuelsensor.outputType.units= 0;
        fuelsensor_get_volumenUnits_name(fuelsensor.outputType.units, buf);

        sysPrint_lcdPrint(1, 0, "Current: " + String(buf));

        //
        menuFuelSensor_volumenUnits.sm0 = -1;
    }

    vscroll.set_db(db_menuFuelSensor_volumenUnits);
    vscroll.job();
    lcd_show_disp(LCD_ROW_2);
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////
VScroll VS_menuFuelSensor_tank;

struct _menuFuelSensor_tank
{
    int sm0;
    //int sm1;
} menuFuelSensor_tank;


static inline void menuFuelSensor_tank_fxKey0(void)
{
}
static inline void menuFuelSensor_tank_fxKey1(void)
{
    VS_menuFuelSensor_tank.sign_up();
}
static inline void menuFuelSensor_tank_fxKey2(void)
{
    VS_menuFuelSensor_tank.sign_down();
}

static inline void menuFuelSensor_tank_fxKey3(void)
{
    taskman_fuelSensor.sm2 = VS_menuFuelSensor_tank.get_markPosc() +1;
    taskman_fuelSensor.sign = TASKMAN_SIGN_ENTER;

    taskman_fuelSensor.sm3 = 0;

    menuFuelSensor_tank.sm0 = 1;//Deja todo listo x cuando se regrese se setee el display

    //con los textos x 1 unica vez
}
static inline void menuFuelSensor_tank_fxKey4(void)
{
    taskman_fuelSensor.sm1 = 0;
    kb_stackPop();
}

PTRFX_retVOID const menuFuelSensor_tank_fxKey[KB_NUM_KEYS] PROGMEM =
{
    menuFuelSensor_tank_fxKey0, menuFuelSensor_tank_fxKey1, menuFuelSensor_tank_fxKey2,
    menuFuelSensor_tank_fxKey3, menuFuelSensor_tank_fxKey4
};

//-----------------------------------------------------------------------------------------------------------

static void menuFuelSensor_tank_job(void)
{
#define MENU_FUELSENSOR_TANK 2

    String db_menuFuelSensor_tank_local[MENU_FUELSENSOR_TANK]=
    {
        str_clearPrint("[1] TYPE OF TANK", 1),
        str_clearPrint("[2] VOLUME CALC.", 1),
    };

    if (menuFuelSensor_tank.sm0 == 0)
    {
        kb_stackPush();
        kb_change_keyDo_pgm(menuFuelSensor_tank_fxKey);

        VS_menuFuelSensor_tank.init(db_menuFuelSensor_tank_local, MENU_FUELSENSOR_TANK, dispShowBuff, 2, FEAT_MARK_ON);

        menuFuelSensor_tank.sm0++;
    }

    if (menuFuelSensor_tank.sm0 == 1)
    {
        lcd.clear();
        sysPrint_lcdPrintPSTR(0, 0, PSTR("[FUEL TANK]"));
        menuFuelSensor_tank.sm0 = -1;
    }

    VS_menuFuelSensor_tank.set_db(db_menuFuelSensor_tank_local);//x la naturaleza "local"
    VS_menuFuelSensor_tank.job();
    lcd_show_disp(LCD_ROW_2);
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////
//VScroll vscroll;

#define MENU_FUELSENSOR_TYPEOFTANK 2
//__________________________________________________
const struct _fuelsensor_db_typeOfTank
{
    char name[15];
}
fuelsensor_db_typeOfTank[MENU_FUELSENSOR_TYPEOFTANK] PROGMEM=
{
    "RECTANGULAR",
    "IRREGULAR",
};
inline static void fuelsensor_get_typeOfTank_name(uint8_t type, char *buf)
{
    strcpy_P(buf, (char *) &fuelsensor_db_typeOfTank[type].name );
}
//__________________________________________________

static inline void menuFuelSensor_typeOfTank_fxKey0(void)
{
}
static inline void menuFuelSensor_typeOfTank_fxKey1(void)
{
    vscroll.sign_up();
}
static inline void menuFuelSensor_typeOfTank_fxKey2(void)
{
    vscroll.sign_down();
}
static inline void menuFuelSensor_typeOfTank_fxKey3(void)
{
    fuelsensor.tank.type = vscroll.get_markPosc();//0=rectangular 1=irregular

    char buf[10];
    fuelsensor_get_typeOfTank_name(fuelsensor.tank.type, buf);
    sysPrint_lcdPrint(1, 0, "Current: " + String(buf));

}
static inline void menuFuelSensor_typeOfTank_fxKey4(void)
{
    taskman_fuelSensor.sm2 = 0;
    kb_stackPop();
}

PTRFX_retVOID const menuFuelSensor_typeOfTank_fxKey[KB_NUM_KEYS] PROGMEM =
{
    menuFuelSensor_typeOfTank_fxKey0, menuFuelSensor_typeOfTank_fxKey1, menuFuelSensor_typeOfTank_fxKey2,
    menuFuelSensor_typeOfTank_fxKey3, menuFuelSensor_typeOfTank_fxKey4
};

//-----------------------------------------------------------------------------------------------------------
struct _menuFuelSensor_typeOfTank
{
    int sm0;
} menuFuelSensor_typeOfTank;

static void menuFuelSensor_typeOfTank_job(void)
{
    char buf[15];
    String db_menuFuelSensor_typeOfTank_local[MENU_FUELSENSOR_TYPEOFTANK];

    for (uint8_t i=0; i<MENU_FUELSENSOR_TYPEOFTANK; i++)
    {
        fuelsensor_get_typeOfTank_name(i, buf);
        db_menuFuelSensor_typeOfTank_local[i] = str_clearPrint(String(i+1)+ "] "+ String(buf), 3);
    }

    if (menuFuelSensor_typeOfTank.sm0 == 0)
    {
        kb_stackPush();
        kb_change_keyDo_pgm(menuFuelSensor_typeOfTank_fxKey);

        lcd.clear();

        vscroll.init(db_menuFuelSensor_typeOfTank_local, MENU_FUELSENSOR_TYPEOFTANK, dispShowBuff, 2, FEAT_MARK_ON);

        sysPrint_lcdPrintPSTR(0, 0, PSTR("[TYPE OF TANK]"));

        fuelsensor_get_typeOfTank_name(fuelsensor.tank.type, buf);
        sysPrint_lcdPrint(1, 0, "Current: " + String(buf));

        menuFuelSensor_typeOfTank.sm0 = -1;
    }

    vscroll.set_db(db_menuFuelSensor_typeOfTank_local);//x la naturaleza "local"
    vscroll.job();
    lcd_show_disp(LCD_ROW_2);
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////

struct _menuFuelSensor_irregularVolume
{
    int sm0;
    int sm1;
} menuFuelSensor_irregularVolume;


//inline static void setnum_digit_blink_set2blank(void);
//inline static void setnum_digit_blink_set2noblank(void);
static void setnum_digit_blink_print(uint8_t blink_toggle, uint8_t setnum_digit_position);
static void setnum_check_lower_boundary(void);
static void print_X(float X);
static void print_A(float A);

//#define PARAM_STR_LENGTH (7+1)
//char PARAM0str[PARAM_STR_LENGTH];//="0000.00";
//char PARAM1str[PARAM_STR_LENGTH];//="0000.00";
//char PARAM2str[PARAM_STR_LENGTH];//="0000.00";


//#define DTOSTRF_SIGN_POS 1

#define X_STR_LENGTH (6+1)//6+\0
#define A_STR_LENGTH (7+1)//7+\0

#define X_STR_DP_PRECISION 2
#define A_STR_DP_PRECISION 2

//original
//char Xstr[X_STR_LENGTH]="000.00" ;
//char Astr[A_STR_LENGTH]="0000.00";

//reutilizando el codigo
#define Xstr PARAM0str
#define Astr PARAM1str

//char Xstr[PARAM_STR_LENGTH]="000.00" ;
//char Astr[PARAM_STR_LENGTH]="0000.00";

#define X_STR_DIG_POS_DP 3
#define A_STR_DIG_POS_DP 4

#define X_STR_DIG_POS_MAX (X_STR_LENGTH-2)
#define A_STR_DIG_POS_MAX (A_STR_LENGTH-2)

#define SETNUM_PARAM_HEIGHT 0
#define SETNUM_PARAM_VOLUME 1

static inline void menuFuelSensor_irregularVolume_fxKey0(void)
{
}
static inline void menuFuelSensor_irregularVolume_fxKey1(void)
{

    char *XAstr;

    if (setnum.param == SETNUM_PARAM_HEIGHT)
        XAstr = Xstr;
    else
        XAstr = Astr;

    if (--XAstr[setnum.digit.position]< '0')
        XAstr[setnum.digit.position] = '9';

    setnum_digit_blink_set2noblank();
}

static inline void menuFuelSensor_irregularVolume_fxKey2(void)
{
    char *XAstr;

    if (setnum.param == SETNUM_PARAM_HEIGHT)
        XAstr = Xstr;
    else
        XAstr = Astr;

    if (++XAstr[setnum.digit.position] > '9')
        XAstr[setnum.digit.position] = '0';

    setnum_digit_blink_set2noblank();
}

static inline void menuFuelSensor_irregularVolume_fxKey3(void)
{
    setnum.digit.position++;

    setnum_check_lower_boundary();

    if (setnum.param == SETNUM_PARAM_HEIGHT)
    {
        if (setnum.digit.position == X_STR_DIG_POS_DP)//skip decimal point
            setnum.digit.position++;

        if (setnum.digit.position>X_STR_DIG_POS_MAX)
        {
            setnum_digit_blink_print(BLINK_TOGGLE_NOBLANK, X_STR_DIG_POS_MAX);//fix latest digit before to leave

            setnum.digit.position = 0;
            setnum.param++;
        }
    }
    if (setnum.param == SETNUM_PARAM_VOLUME)
    {
        if (setnum.digit.position == A_STR_DIG_POS_DP)//skip decimal point
            setnum.digit.position++;

        if (setnum.digit.position>A_STR_DIG_POS_MAX)
        {
            setnum_digit_blink_print(BLINK_TOGGLE_NOBLANK, A_STR_DIG_POS_MAX);//fix latest digit before to leave

            setnum.digit.position = 0;
            setnum.param--;
        }
    }

    setnum_digit_blink_set2blank();
}

static inline void menuFuelSensor_irregularVolume_fxKey4(void)
{


    uint8_t node_counter = fuelsensor.tank.irregular.spline.node_counter;

    //1.- check consistency
    taskman_fuelSensor.sign = TASKMAN_SIGN_ENTER;

    taskman_fuelSensor.sm3 = 1; //set default -> Error

    setnum.bf.error_equalzero_length = 0;
    setnum.bf.error_equalzero_volume = 0;
    setnum.bf.error_consistency_lenght = 0;
    setnum.bf.error_consistency_volume = 0;

    setnum_check_lower_boundary();//update Xstr and Astr!

    float Xentered = strtod(Xstr, (char**)0);
    float Aentered = strtod(Astr, (char**)0);

    if (Xentered == 0.0f)
        setnum.bf.error_equalzero_length = 1;

    if (Aentered == 0.0f)
        setnum.bf.error_equalzero_volume = 1;

    if (node_counter > 0)
    {
        if (Xentered == fuelsensor.tank.irregular.spline.node[node_counter-1].X)
            setnum.bf.error_consistency_lenght = 1;

        if (Aentered == fuelsensor.tank.irregular.spline.node[node_counter-1].A)
            setnum.bf.error_consistency_volume = 1;
    }
    //------------------------------------------------------------------------------
    if ( (setnum.bitflag & 0x1E) == 0)//NO ERRORS
    {
        if (fuelsensor.tank.irregular.spline.node_counter > SPLINE_NODES_MAX)
        {
            /*
            print message("TABLE HAS REACH THE MAX NUM"))

            */
        }
        else
        {
            fuelsensor.tank.irregular.spline.node[node_counter].X = Xentered;
            fuelsensor.tank.irregular.spline.node[node_counter].A = Aentered;

            //save & continue entering new node?
            //taskman_fuelSensor.sign = TASKMAN_SIGN_ENTER;
            taskman_fuelSensor.sm3 = 2;
            menuFuelSensor_irregularVolume.sm1 = 0;
        }
    }

}

PTRFX_retVOID const menuFuelSensor_irregularVolume_fxKey[KB_NUM_KEYS] PROGMEM =
{
    menuFuelSensor_irregularVolume_fxKey0, menuFuelSensor_irregularVolume_fxKey1, menuFuelSensor_irregularVolume_fxKey2,
    menuFuelSensor_irregularVolume_fxKey3, menuFuelSensor_irregularVolume_fxKey4
};

static void menuFuelSensor_irregularVolume_fill_spline_nodes(void);

static void menuFuelSensor_irregularVolume_job(void)
{
    if (menuFuelSensor_irregularVolume.sm0 == 0)
    {
        kb_stackPush();
        kb_change_keyDo_pgm(menuFuelSensor_irregularVolume_fxKey);

        menuFuelSensor_irregularVolume.sm1 = 0x0;
        menuFuelSensor_irregularVolume.sm0 = -1;

//        Xstr[PARAM_STR_LENGTH]="000.00" ;
//        Astr[PARAM_STR_LENGTH]="0000.00";

    }

    if (menuFuelSensor_irregularVolume.sm1 == 0)
    {
        lcd.clear();
        sysPrint_lcdPrintPSTR(0, 0, PSTR("[NODE-TABLE]"));

        //fuelsensor_get_splineNodeUnitHeigth_name(fuelsensor.tank.irregular.spline.units.height, buf0);
        //fuelsensor_get_splineNodeUnitVolume_name(fuelsensor.tank.irregular.spline.units.volume, buf1);
        //sysPrint_lcdPrintPSTR(2, 4, "["+String(buf0)+"] , ["+ String(buf1)+"]"));
        sysPrint_lcdPrintPSTR(2, 3, PSTR("[cm]  , [gallons]"));
        lcd.printAtPosc(3, 9, ",");

        menuFuelSensor_irregularVolume.sm1++;
    }
    if (menuFuelSensor_irregularVolume.sm1 == 1)
    {
        //setnum_digit_blink_set2blank();//begin with blink "blank space"
        setnum.param = SETNUM_PARAM_HEIGHT;
        setnum.digit.position = 0;

        uint8_t node_counter = fuelsensor.tank.irregular.spline.node_counter;
        sysPrint_lcdPrint(1, STR_CENTER, "NODE "+String( node_counter+1));

        if (node_counter > 0)
        {
            fuelsensor.tank.irregular.spline.node[node_counter].X = fuelsensor.tank.irregular.spline.node[node_counter-1].X;
            fuelsensor.tank.irregular.spline.node[node_counter].A = fuelsensor.tank.irregular.spline.node[node_counter-1].A;
        }
        print_X(fuelsensor.tank.irregular.spline.node[node_counter].X);
        print_A(fuelsensor.tank.irregular.spline.node[node_counter].A);

        menuFuelSensor_irregularVolume.sm1 = -1;
    }
    //-------- blinking ----------
    if (setnum.digit.blink.sm0 == 0)
    {
        if ( (millis() - setnum.digit.blink.last_millis) > 500)
        {
            setnum.digit.blink.bf.toggle = !setnum.digit.blink.bf.toggle;
            setnum.digit.blink.sm0++;
        }
    }
    if (setnum.digit.blink.sm0 == 1)
    {
        setnum_digit_blink_print(setnum.digit.blink.bf.toggle, setnum.digit.position);
        //
        setnum.digit.blink.last_millis = millis();
        setnum.digit.blink.sm0 = 0;
    }
}

static void setnum_check_lower_boundary(void)
{
    char *p;
    float n_entered, limit;
    uint8_t node_counter = fuelsensor.tank.irregular.spline.node_counter;

    if (setnum.param == SETNUM_PARAM_HEIGHT)
    {
        p = Xstr;
        limit = fuelsensor.tank.irregular.spline.node[node_counter].X;
    }
    else
    {
        p = Astr;
        limit = fuelsensor.tank.irregular.spline.node[node_counter].A;
    }

    n_entered = strtod(p, (char**)0);

    if (n_entered < limit)
        n_entered = limit;

    if (setnum.param == SETNUM_PARAM_HEIGHT)
        print_X(n_entered);
    else
        print_A(n_entered);
}

static void print_X(float X)
{
    dtostrf(X, X_STR_LENGTH-DTOSTRF_SIGN_POS, X_STR_DP_PRECISION, Xstr);
    dtostrf_fill_zero(Xstr);
    lcd.printAtPosc(3,2, String(Xstr));
}
static void print_A(float A)
{
    dtostrf(A, A_STR_LENGTH-DTOSTRF_SIGN_POS, A_STR_DP_PRECISION, Astr);
    dtostrf_fill_zero(Astr);
    lcd.printAtPosc(3,12, String(Astr));
}

inline static void setnum_digit_blink_set2blank(void)
{
    setnum.digit.blink.sm0 = 1;
    setnum.digit.blink.bf.toggle = BLINK_TOGGLE_BLANK;
}

inline static void setnum_digit_blink_set2noblank(void)
{
    setnum.digit.blink.sm0 = 1;
    setnum.digit.blink.bf.toggle = BLINK_TOGGLE_NOBLANK;
}

static void setnum_digit_blink_print(uint8_t blink_toggle, uint8_t setnum_digit_position )
{
    uint8_t col;
    char xa_digit_str=' ';
    char *XAstr;

    if (setnum.param == SETNUM_PARAM_HEIGHT)
    {
        col=2;
        XAstr = Xstr;
    }
    else
    {
        col=12;
        XAstr = Astr;
    }

    if (blink_toggle == BLINK_TOGGLE_NOBLANK)
        xa_digit_str = XAstr[setnum_digit_position];

    col += setnum_digit_position;
    lcd.printAtPosc(3, col,String(xa_digit_str));
}


//////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////
//VScroll vscroll;

struct _menuFuelSensor_irregularVolume_errorConsistency
{
    int sm0;
    int sm1;
    int opt;
} menuFuelSensor_irregularVolume_errorConsistency;

static void menuFuelSensor_irregularVolume_errorConsistency_fxKey0(void)
{
    if (menuFuelSensor_irregularVolume_errorConsistency.opt == 0)
    {
        menuFuelSensor_irregularVolume_errorConsistency.opt++;//skip the error
        menuFuelSensor_irregularVolume_errorConsistency.sm1 = 0;
    }
}
static void menuFuelSensor_irregularVolume_errorConsistency_fxKey1(void)
{
    if (menuFuelSensor_irregularVolume_errorConsistency.opt == 0)
    {
        menuFuelSensor_irregularVolume_errorConsistency.opt++;//skip the error
        menuFuelSensor_irregularVolume_errorConsistency.sm1 = 0;
    }
    else
    {
        vscroll.sign_up();
    }
}
static void menuFuelSensor_irregularVolume_errorConsistency_fxKey2(void)
{
    if (menuFuelSensor_irregularVolume_errorConsistency.opt == 0)
    {
        menuFuelSensor_irregularVolume_errorConsistency.opt++;//skip the error
        menuFuelSensor_irregularVolume_errorConsistency.sm1 = 0;
    }
    else
    {
        vscroll.sign_down();
    }
}
static void menuFuelSensor_irregularVolume_errorConsistency_fxKey3(void)
{
    if (menuFuelSensor_irregularVolume_errorConsistency.opt == 0)
    {
        menuFuelSensor_irregularVolume_errorConsistency.opt++;//skip the error
        menuFuelSensor_irregularVolume_errorConsistency.sm1 = 0;
    }
    else
    {
        uint8_t posc = vscroll.get_markPosc();

        if (posc == 0)
        {
            menuFuelSensor_irregularVolume.sm1 = 0;
            taskman_fuelSensor.sm3 = 0;
            kb_stackPop();
        }
        else
        {
            //check minimum
            //check min
            if (fuelsensor.tank.irregular.spline.node_counter < SPLINE_NODES_MIN)
            {
                taskman_fuelSensor.sm3 = 3;//show minNode
                taskman_fuelSensor.sign = TASKMAN_SIGN_ENTER;
            }
            else
            {
                //exit to menu "IRREGULAR TANK"
                kb_stackPop();
                kb_stackPop();
                taskman_fuelSensor.sm2 = 0;
                //
            }
        }
    }
}
static void menuFuelSensor_irregularVolume_errorConsistency_fxKey4(void)
{
    if (menuFuelSensor_irregularVolume_errorConsistency.opt == 0)
    {
        menuFuelSensor_irregularVolume_errorConsistency.opt++;//skip the error
        menuFuelSensor_irregularVolume_errorConsistency.sm1 = 0;
    }
    else
    {

    }
}

PTRFX_retVOID const menuFuelSensor_irregularVolume_errorConsistency_fxKey[KB_NUM_KEYS] PROGMEM =
{
    menuFuelSensor_irregularVolume_errorConsistency_fxKey0, menuFuelSensor_irregularVolume_errorConsistency_fxKey1, menuFuelSensor_irregularVolume_errorConsistency_fxKey2,
    menuFuelSensor_irregularVolume_errorConsistency_fxKey3, menuFuelSensor_irregularVolume_errorConsistency_fxKey4
};

static void menuFuelSensor_irregularVolume_errorConsistency_job(void)
{
    uint8_t node_counter = fuelsensor.tank.irregular.spline.node_counter;

    if (menuFuelSensor_irregularVolume_errorConsistency.sm0 == 0)
    {
        kb_stackPush();
        kb_change_keyDo_pgm(menuFuelSensor_irregularVolume_errorConsistency_fxKey);

        lcd.clear();

        sysPrint_lcdPrintPSTR(LCD_ROW_0, 0, PSTR("[ERROR]"));
        //
        menuFuelSensor_irregularVolume_errorConsistency.opt = 0x00;
        menuFuelSensor_irregularVolume_errorConsistency.sm1 = 0;
        //
        menuFuelSensor_irregularVolume_errorConsistency.sm0 = -1;
    }

    if (menuFuelSensor_irregularVolume_errorConsistency.opt == 0)
    {
        if (menuFuelSensor_irregularVolume_errorConsistency.sm1 == 0)
        {
            String msg="";

            if ( (setnum.bf.error_equalzero_length) || (setnum.bf.error_consistency_lenght) )
                msg+="[Length] ";

            if ( (setnum.bf.error_equalzero_volume) || (setnum.bf.error_consistency_volume) )
                msg+="[Volume]";

            sysPrint_lcdPrint(LCD_ROW_1, STR_CENTER, msg);

            if ( (setnum.bitflag &  (0x03<<3)) != 0)
            {
                sysPrint_lcdPrintPSTR(LCD_ROW_2, STR_CENTER, PSTR("must be different"));
                sysPrint_lcdPrintPSTR(LCD_ROW_3, STR_CENTER, PSTR("to zero"));
            }
            else if ( (setnum.bitflag &  (0x03<<1) )!= 0)
            {
                sysPrint_lcdPrintPSTR(LCD_ROW_2, STR_CENTER, PSTR("must be greater"));
                sysPrint_lcdPrintPSTR(LCD_ROW_3, STR_CENTER, PSTR("than previous node"));
            }
            menuFuelSensor_irregularVolume_errorConsistency.sm1 = -1;
        }
    }
    else
    {
        String db_vscroll[2] =
        {
            str_clearPrint("1] Yes", 7),
            str_clearPrint("2] No", 7),
        };

        if (menuFuelSensor_irregularVolume_errorConsistency.sm1 == 0)
        {
            sysPrint_lcdPrintPSTR(LCD_ROW_0, STR_CENTER, PSTR("Discard & continue"));
            sysPrint_lcdPrintPSTR(LCD_ROW_1, STR_CENTER, PSTR("entering new node?"));

            vscroll.init(db_vscroll, 2, dispShowBuff, 2, FEAT_MARK_ON);

            menuFuelSensor_irregularVolume_errorConsistency.sm1 = -1;
        }

        vscroll.set_db(db_vscroll);
        vscroll.job();
        lcd_show_disp(LCD_ROW_2);
    }
}

////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////

struct _menuFuelSensor_irregularVolume_save_continue
{
    int sm0;
    int opt;
    int sm1;
} menuFuelSensor_irregularVolume_save_continue;

static void menuFuelSensor_irregularVolume_save_continue_fxKey0(void)
{
}
static void menuFuelSensor_irregularVolume_save_continue_fxKey1(void)
{
    vscroll.sign_up();
}
static void menuFuelSensor_irregularVolume_save_continue_fxKey2(void)
{
    vscroll.sign_down();
}
static void menuFuelSensor_irregularVolume_save_continue_fxKey3(void)
{
    uint8_t posc = vscroll.get_markPosc();

    if (menuFuelSensor_irregularVolume_save_continue.opt == 0)//step 0
    {
        if (posc == 0)//Yes
        {

            //save data to EEPROM

            //fuelsensor.tank.irregular.spline.node_counter++;

            if (fuelsensor.tank.irregular.spline.node_counter == (SPLINE_NODES_MAX-1))
            {
                //visualizar maximum...
                taskman_fuelSensor.sm3 = 4;
                taskman_fuelSensor.sign = TASKMAN_SIGN_ENTER;

            }
            else
            {
                menuFuelSensor_irregularVolume_save_continue.sm1 = 0;

                menuFuelSensor_irregularVolume_save_continue.opt++;//next step
            }

        }
        else//No
        {
            if (fuelsensor.tank.irregular.spline.node_counter < SPLINE_NODES_MIN)
            {
                taskman_fuelSensor.sm3 = 3;//show minNode
                taskman_fuelSensor.sign = TASKMAN_SIGN_ENTER;
            }
            else
            {
                menuFuelSensor_irregularVolume_save_continue.sm1 = 0;
                menuFuelSensor_irregularVolume_save_continue.opt++;
            }
        }
    }
    else//step 1
    {
        if (posc == 0)
        {
            //Yes: continue entered
            fuelsensor.tank.irregular.spline.node_counter++;

//            if (fuelsensor.tank.irregular.spline.node_counter > SPLINE_NODES_MAX)
//            {
//
//            }
//            else
//            {
            taskman_fuelSensor.sm3 = 0;
            menuFuelSensor_irregularVolume.sm1 = 0;
            kb_stackPop();
            // }

        }
        else
        {
            //check min
            if (fuelsensor.tank.irregular.spline.node_counter < SPLINE_NODES_MIN)
            {
                taskman_fuelSensor.sm3 = 3;//show minNode
                taskman_fuelSensor.sign = TASKMAN_SIGN_ENTER;
            }
            else
            {
                //exit to menu "IRREGULAR TANK"
                kb_stackPop();
                kb_stackPop();
                taskman_fuelSensor.sm2 = 0;
                //
            }
        }
    }
}
static void menuFuelSensor_irregularVolume_save_continue_fxKey4(void)
{
}

PTRFX_retVOID const menuFuelSensor_irregularVolume_save_continue_fxKey[KB_NUM_KEYS] PROGMEM =
{
    menuFuelSensor_irregularVolume_save_continue_fxKey0, menuFuelSensor_irregularVolume_save_continue_fxKey1, menuFuelSensor_irregularVolume_save_continue_fxKey2,
    menuFuelSensor_irregularVolume_save_continue_fxKey3, menuFuelSensor_irregularVolume_save_continue_fxKey4
};

static void menuFuelSensor_irregularVolume_save_continue_job(void)
{
    if (menuFuelSensor_irregularVolume_save_continue.sm0 == 0)
    {
        kb_stackPush();
        kb_change_keyDo_pgm(menuFuelSensor_irregularVolume_save_continue_fxKey);

        menuFuelSensor_irregularVolume_save_continue.opt = 0;
        menuFuelSensor_irregularVolume_save_continue.sm1 = 0;

        menuFuelSensor_irregularVolume_save_continue.sm0 = -1;
    }

    String db_vscroll[2] =
    {
        str_clearPrint("1] Yes", 7),
        str_clearPrint("2] No", 7),
    };

    if (menuFuelSensor_irregularVolume_save_continue.opt == 0)
    {
        if (menuFuelSensor_irregularVolume_save_continue.sm1 == 0)
        {
            vscroll.init(db_vscroll, 2, dispShowBuff, 2, FEAT_MARK_ON);

            lcd.clear();
            sysPrint_lcdPrintPSTR(LCD_ROW_0, STR_CENTER, PSTR("Save node?"));

            menuFuelSensor_irregularVolume_save_continue.sm1 = -1;
        }
    }
    else
    {
        if (menuFuelSensor_irregularVolume_save_continue.sm1 == 0)
        {
            vscroll.init(db_vscroll, 2, dispShowBuff, 2, FEAT_MARK_ON);

            lcd.clear();

            sysPrint_lcdPrintPSTR(LCD_ROW_0, STR_CENTER, PSTR("Continue entering"));
            sysPrint_lcdPrintPSTR(LCD_ROW_1, STR_CENTER, PSTR("new node?"));//then EXIT

            menuFuelSensor_irregularVolume_save_continue.sm1 = -1;
        }
    }
    vscroll.set_db(db_vscroll);
    vscroll.job();
    lcd_show_disp(LCD_ROW_2);
}

////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////
struct _menuFuelSensor_irregularVolume_minNode
{
    int sm0;
    int sm1;
    int opt;
} menuFuelSensor_irregularVolume_minNode;

static void menuFuelSensor_irregularVolume_minNode_fxKey0(void)
{
    if (menuFuelSensor_irregularVolume_minNode.opt == 0)
    {
        menuFuelSensor_irregularVolume_minNode.opt++;//skip the warning
        menuFuelSensor_irregularVolume_minNode.sm1 = 0;
    }
}
static void menuFuelSensor_irregularVolume_minNode_fxKey1(void)
{
    if (menuFuelSensor_irregularVolume_minNode.opt == 0)
    {
        menuFuelSensor_irregularVolume_minNode.opt++;//skip the warning
        menuFuelSensor_irregularVolume_minNode.sm1 = 0;
    }
    else
    {
        vscroll.sign_up();
    }
}
static void menuFuelSensor_irregularVolume_minNode_fxKey2(void)
{
    if (menuFuelSensor_irregularVolume_minNode.opt == 0)
    {
        menuFuelSensor_irregularVolume_minNode.opt++;//skip the warning
        menuFuelSensor_irregularVolume_minNode.sm1 = 0;
    }
    else
    {
        vscroll.sign_down();
    }
}
static void menuFuelSensor_irregularVolume_minNode_fxKey3(void)
{
    if (menuFuelSensor_irregularVolume_minNode.opt == 0)
    {
        menuFuelSensor_irregularVolume_minNode.opt++;//skip the warning
        menuFuelSensor_irregularVolume_minNode.sm1 = 0;
    }
    else
    {
        uint8_t posc = vscroll.get_markPosc();

        if (posc == 0)
        {
            //exit to menu "IRREGULAR TANK"
            kb_stackPop();
            kb_stackPop();
            taskman_fuelSensor.sm2 = 0;
            //
        }
        else
        {
            menuFuelSensor_irregularVolume.sm1 = 0;
            taskman_fuelSensor.sm3 = 0;
            kb_stackPop();
        }
    }
}
static void menuFuelSensor_irregularVolume_minNode_fxKey4(void)
{
    if (menuFuelSensor_irregularVolume_minNode.opt == 0)
    {
        menuFuelSensor_irregularVolume_minNode.opt++;//skip the warning
        menuFuelSensor_irregularVolume_minNode.sm1 = 0;
    }
    else
    {

    }
}

PTRFX_retVOID const menuFuelSensor_irregularVolume_minNode_fxKey[KB_NUM_KEYS] PROGMEM =
{
    menuFuelSensor_irregularVolume_minNode_fxKey0, menuFuelSensor_irregularVolume_minNode_fxKey1, menuFuelSensor_irregularVolume_minNode_fxKey2,
    menuFuelSensor_irregularVolume_minNode_fxKey3, menuFuelSensor_irregularVolume_minNode_fxKey4
};

static void menuFuelSensor_irregularVolume_minNode_job(void)
{
    uint8_t node_counter = fuelsensor.tank.irregular.spline.node_counter;

    if (menuFuelSensor_irregularVolume_minNode.sm0 == 0)
    {
        kb_stackPush();
        kb_change_keyDo_pgm(menuFuelSensor_irregularVolume_minNode_fxKey);

        //
        menuFuelSensor_irregularVolume_minNode.opt = 0x00;
        menuFuelSensor_irregularVolume_minNode.sm1 = 0;
        //
        menuFuelSensor_irregularVolume_minNode.sm0 = -1;
    }

    if (menuFuelSensor_irregularVolume_minNode.opt == 0)
    {
        if (menuFuelSensor_irregularVolume_minNode.sm1 == 0)
        {
            lcd.clear();

            sysPrint_lcdPrintPSTR(LCD_ROW_0, STR_CENTER, PSTR("[WARNING]"));
            sysPrint_lcdPrintPSTR(LCD_ROW_1, STR_CENTER, PSTR("Number of node is"));
            sysPrint_lcdPrint(LCD_ROW_2, STR_CENTER, "lower than "+ String(SPLINE_NODES_MIN));
            sysPrint_lcdPrintPSTR(LCD_ROW_3, STR_CENTER, PSTR("(Press any key...)"));

            menuFuelSensor_irregularVolume_minNode.sm1 = -1;
        }
    }
    else
    {
        String db_vscroll[2] =
        {
            str_clearPrint("1] Yes", 7),
            str_clearPrint("2] No", 7),
        };

        if (menuFuelSensor_irregularVolume_minNode.sm1 == 0)
        {
            lcd.clear();

            sysPrint_lcdPrintPSTR(LCD_ROW_0, STR_CENTER, PSTR("Exit & discard the"));
            sysPrint_lcdPrintPSTR(LCD_ROW_1, STR_CENTER, PSTR("node-table anyway?"));

            vscroll.init(db_vscroll, 2, dispShowBuff, 2, FEAT_MARK_ON);

            menuFuelSensor_irregularVolume_minNode.sm1 = -1;
        }

        vscroll.set_db(db_vscroll);
        vscroll.job();
        lcd_show_disp(LCD_ROW_2);
    }
}

////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////
struct _menuFuelSensor_irregularVolume_maximum_size
{
    int sm0;
} menuFuelSensor_irregularVolume_maximum_size;

void _escape(void)
{
    //exit to menu "IRREGULAR TANK"
    kb_stackPop();
    kb_stackPop();
    taskman_fuelSensor.sm2 = 0;
    //
}
static void menuFuelSensor_irregularVolume_maximum_size_fxKey0(void)
{
    _escape();
}
static void menuFuelSensor_irregularVolume_maximum_size_fxKey1(void)
{
    _escape();
}
static void menuFuelSensor_irregularVolume_maximum_size_fxKey2(void)
{
    _escape();
}
static void menuFuelSensor_irregularVolume_maximum_size_fxKey3(void)
{
    _escape();
}
static void menuFuelSensor_irregularVolume_maximum_size_fxKey4(void)
{
    _escape();
}

PTRFX_retVOID const menuFuelSensor_irregularVolume_maximum_size_fxKey[KB_NUM_KEYS] PROGMEM =
{
    menuFuelSensor_irregularVolume_maximum_size_fxKey0, menuFuelSensor_irregularVolume_maximum_size_fxKey1, menuFuelSensor_irregularVolume_maximum_size_fxKey2,
    menuFuelSensor_irregularVolume_maximum_size_fxKey3, menuFuelSensor_irregularVolume_maximum_size_fxKey4
};

static void menuFuelSensor_irregularVolume_maximum_size_job(void)
{
    if (menuFuelSensor_irregularVolume_maximum_size.sm0 == 0)
    {
        kb_stackPush();
        kb_change_keyDo_pgm(menuFuelSensor_irregularVolume_maximum_size_fxKey);

        lcd.clear();

        sysPrint_lcdPrintPSTR(LCD_ROW_0, STR_CENTER, PSTR("Node-table has"));
        sysPrint_lcdPrintPSTR(LCD_ROW_1, STR_CENTER, PSTR("reached maximum"));
        sysPrint_lcdPrintPSTR(LCD_ROW_2, STR_CENTER, PSTR("size. Press any"));
        sysPrint_lcdPrintPSTR(LCD_ROW_3, STR_CENTER, PSTR("key to exit..."));

        menuFuelSensor_irregularVolume_maximum_size.sm0 = -1;
    }
}

////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////
struct _taskman_fuelSensor taskman_fuelSensor;

void mainMenu_fuelSensor_job(void)
{
    if (taskman_fuelSensor.sign == TASKMAN_SIGN_ENTER)
    {
        taskman_fuelSensor.reInitJob = 1;
    }

    if (taskman_fuelSensor.sm0 == 0)
    {
        if (taskman_fuelSensor.reInitJob)
            menuFuelSensor_warning.sm0 = 0;

        menuFuelSensor_warning_job();
    }

    if (taskman_fuelSensor.sm0 == 1)
    {
        if (taskman_fuelSensor.sm1 == 0)
        {
            if (taskman_fuelSensor.reInitJob)
                menuFuelSensor_mainMenu.sm0 = 0;

            menuFuelSensor_mainMenu_job();
        }

        if (taskman_fuelSensor.sm1 == 1)
        {
            if (taskman_fuelSensor.reInitJob)
                menuFuelSensor_modelOfsensor.sm0 = 0;

            menuFuelSensor_modelOfsensor_job();
        }

        if (taskman_fuelSensor.sm1 == 2)
        {
            if (taskman_fuelSensor.sm2 == 0)
            {
                if (taskman_fuelSensor.reInitJob)
                    menuFuelSensor_calibration.sm0 = 0;

                menuFuelSensor_calibration_job();
            }
            if (taskman_fuelSensor.sm2 == 1)
            {
                //do Full/Zero calibration
                if (taskman_fuelSensor.reInitJob)
                    menuFuelSensor_lengthTankDepth_FullZeroCalibration.sm0 = 0;

                menuFuelSensor_lengthTankDepth_FullZeroCalibration_job();

            }
            if (taskman_fuelSensor.sm2 == 2)
            {
                if (taskman_fuelSensor.sm3 == 0)
                {
                    if (taskman_fuelSensor.reInitJob)
                        menuFuelSensor_lengthTankDepth.sm0 = 0;

                    menuFuelSensor_lengthTankDepth_job();
                }

                if (taskman_fuelSensor.sm3 == 1)
                {
                    if (taskman_fuelSensor.reInitJob)
                        menuFuelSensor_lengthTankDepth_errorConsistency.sm0 = 0;

                    menuFuelSensor_lengthTankDepth_errorConsistency_job();

                }

                if (taskman_fuelSensor.sm3 == 2)
                {
                    if (taskman_fuelSensor.reInitJob)
                        menuFuelSensor_lengthTankDepth_noErrorConsistency.sm0 = 0;

                    menuFuelSensor_lengthTankDepth_noErrorConsistency_job();
                }
            }
        }

        if (taskman_fuelSensor.sm1 == 3)
        {
            if (taskman_fuelSensor.sm2 == 0)
            {
                if (taskman_fuelSensor.reInitJob)
                    menuFuelSensor_outputType.sm0 = 0;

                menuFuelSensor_outputType_job();
            }

            if (taskman_fuelSensor.sm2 == 1)
            {
                if (taskman_fuelSensor.reInitJob)
                    menuFuelSensor_lengthUnits.sm0 = 0;

                menuFuelSensor_lengthUnits_job();
            }

            if (taskman_fuelSensor.sm2 == 2)
            {
                if (taskman_fuelSensor.reInitJob)
                    menuFuelSensor_volumenUnits.sm0 = 0;

                menuFuelSensor_volumenUnits_job();
            }

        }

        if (taskman_fuelSensor.sm1 == 4)
        {
            if (taskman_fuelSensor.sm2 == 0)
            {
                if (taskman_fuelSensor.reInitJob)
                    menuFuelSensor_tank.sm0 = 0;

                menuFuelSensor_tank_job();
            }

            if (taskman_fuelSensor.sm2 == 1)
            {
                if (taskman_fuelSensor.reInitJob)
                    menuFuelSensor_typeOfTank.sm0 = 0;

                menuFuelSensor_typeOfTank_job();//length x witdh
            }
            if (taskman_fuelSensor.sm2 == 2)
            {
                if (taskman_fuelSensor.sm3 == 0)
                {
                    if (taskman_fuelSensor.reInitJob)
                        menuFuelSensor_irregularVolume.sm0 = 0;

                    menuFuelSensor_irregularVolume_job();
                }
                if (taskman_fuelSensor.sm3 == 1)
                {
                    if (taskman_fuelSensor.reInitJob)
                        menuFuelSensor_irregularVolume_errorConsistency.sm0 = 0;

                    menuFuelSensor_irregularVolume_errorConsistency_job();
                }
                if (taskman_fuelSensor.sm3 == 2)
                {
                    if (taskman_fuelSensor.reInitJob)
                        menuFuelSensor_irregularVolume_save_continue.sm0 = 0;

                    menuFuelSensor_irregularVolume_save_continue_job();
                }
                if (taskman_fuelSensor.sm3 == 3)
                {
                    if (taskman_fuelSensor.reInitJob)
                        menuFuelSensor_irregularVolume_minNode.sm0 = 0;

                    menuFuelSensor_irregularVolume_minNode_job();
                }
                if (taskman_fuelSensor.sm3 == 4)
                {
                    if (taskman_fuelSensor.reInitJob)
                        menuFuelSensor_irregularVolume_maximum_size.sm0 = 0;

                    menuFuelSensor_irregularVolume_maximum_size_job();
                }

            }
        }
    }

    //
    if(taskman_fuelSensor.reInitJob == 1)
        taskman_fuelSensor.reInitJob = 0;

    if (taskman_fuelSensor.sign == TASKMAN_SIGN_ENTER)
        taskman_fuelSensor.sign = TASKMAN_SIGN_CLEAR;
}
