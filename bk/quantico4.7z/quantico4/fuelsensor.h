#ifndef FUELSENSOR_H_
#define FUELSENSOR_H_

#include "spline.h"

enum FS_OUTPUTTYPE{LENGTH=0, VOLUME};

struct _fsEEPROM
{
    uint8_t model;

     struct _outputType
    {
        FS_OUTPUTTYPE type;
        uint8_t units;
    }outputType;

    struct _tank
    {
        uint8_t type;

        struct _rectangular
        {
            struct _area
            {
                uint8_t length;
                uint8_t width;
            } area;

        } rectangular;

        struct _irregular
        {
            struct _spline
            {
                struct _node
                {
                    float X;//x
                    float A;//f(x)

                } node[SPLINE_NODES_MAX];//#define SPLINE_NODES_MAX in spline.h

             uint8_t node_counter;

            } spline;

        } irregular;

    } tank;

    struct _calib//ration
    {
        struct _tank
        {
            float innertank;//cm
            float zero2full;//cm
            float full2upper;//cm

        }tank;

    } calib;

    struct
    {
        unsigned lengthsTankdepth_consistent:1;
        unsigned __a:7;

    }bf;
};

struct _fuelsensor
{
    float value;
    struct
    {
        unsigned do_fullzero:1;
        unsigned __a:7;

    }bf;
    struct _fsEEPROM fsEEPROM;
};

extern struct _fuelsensor fuelsensor;
//
//#define FS_UNITMEA_LENGTH_PERCENTAGE 0
//#define FS_UNITMEA_LENGTH_CENTIMETERS 1
//#define FS_UNITMEA_LENGTH_METERS 2
//
//#define FS_UNITMEA_VOLUME_GALLONS 0
//#define FS_UNITMEA_VOLUME_LITERS 1
#define FS_DO_FULL_CALIB 1
#define FS_DO_ZERO_CALIB 0

#endif // FUELSENSOR_H_
