#ifndef MENU_CONTACTINFO_H_
#define MENU_CONTACTINFO_H_


    void menu_contactInfo_handler(void);
    void menu_contactInfo_db_update_data(void);

#endif // MENU_CONTACTINFO_H_



