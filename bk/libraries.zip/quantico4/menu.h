#ifndef MENU_H_
#define MENU_H_
/*
    struct _menu
    {
        int8_t actual;
        int8_t actual_last;
    };

    extern struct _menu menu;
*/

#endif // MENU_H_
