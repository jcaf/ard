#ifndef SYSTEM_H_
#define SYSTEM_H

    #include <LiquidCrystal.h>
    #include "vscroll.h"

    #define DEBUG_SYSTEM

    #define WIZNET_CS 10
    #define SDCARD_CS 4
    //#define ATMEGA_SPI_SS 53

    typedef uint8_t (*PTRFX_retUINT8_T)(void);
    typedef uint16_t (*PTRFX_retUINT16_T)(void);
    typedef void (*PTRFX_retVOID)(void);


    #define DTOSTRF_PREC 3
    #define DTOSTRF_NUM_INT 2

    #define DTOSTRF_WIDTH (1+DTOSTRF_NUM_INT+1+DTOSTRF_PREC) //SIGN+NUM INT+.+DECIMALS
    #define DTOSTRF_SIZE_BUF (DTOSTRF_WIDTH+1)               //DTOSTRF_WIDTH+ NULL_TERMINATOR


    extern LiquidCrystal lcd;
    extern VScroll vscroll;



    #define DISP_SHOW_BUFF_LENGTH 3
    extern String dispShowBuff[DISP_SHOW_BUFF_LENGTH];



    struct _scheduler
    {
      struct
      {
        struct
        {
          unsigned ltc6804:1;
          unsigned __a:7;
        }bf;

      }job;
    };

    extern struct _scheduler sch;

#endif
