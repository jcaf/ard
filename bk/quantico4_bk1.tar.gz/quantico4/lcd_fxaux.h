#ifndef LCD_FXAUX_H_
#define LCD_FXAUX_H_
    
    #define LCD_ROW 4
	#define LCD_COL 20

    void lcd_show_disp(void);
    String str_format(String pstr,  uint8_t posc_i);

#endif