#include <Arduino.h>
#include "menu_mainMenu.h"
#include "system.h"

#include "LTC68042.h"
#include "ltc6804.h"

#include "menu.h"

// 0 Menu
// 1 Up
// 2 Down
// 3 Enter
// 4 eScape
/*
void key0_fx(void)
{

}
void key1_fx(void)
{
    menu.actual--;
    //if (menu.actual < 0)
      //  menu.actual = 0;
}
void key2_fx(void)
{
    menu.actual++;
    //if (menu.actual > MENU_MAXNUM-1)
      //  menu.actual = MENU_MAXNUM-1;
}
void key3_fx(void)
{

}
void key4_fx(void)
{

}



void menu_mainMenu_handler(void)
{
    static int8_t sm0=0;

    if (sm0 == 0)
    {
        lcd.print(F("[MAIN MENU]"));

        sm0++;
    }
}


void menu_mainMenu_db_update_data(void)
{
    uint8_t num_ic=1;


    char char_buff[DTOSTRF_SIZE_BUF];
    float cv;
    String str;

    for (uint8_t num_cell=0; num_cell<12; num_cell++)
    {
        cv= vcellf[num_ic][num_cell];
        str="C" + String(num_cell+1) + "=" + dtostrf(cv, DTOSTRF_WIDTH, DTOSTRF_PREC, char_buff) + "V";

        db_global[num_cell]=str_format(str, 4);
    }

}


*/
