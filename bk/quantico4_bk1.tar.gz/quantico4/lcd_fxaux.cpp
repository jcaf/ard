#include <Arduino.h>
#include "lcd_fxaux.h"
#include "system.h"

void lcd_show_disp(void)
{
  uint8_t cr = 0; //count row
  for (uint8_t r = 1; r < LCD_ROW; r++)
  {
    lcd.setCursor(0, r);
    lcd.print(dispShowBuff[cr]);
    cr++;
  }
}


String str_format(String pstr,  uint8_t posc_i)
{
  char arr[LCD_COL + 1];
  char arr1[LCD_COL + 1];
  uint8_t length;
  uint8_t c = 0;

  for (uint8_t i = 0; i < LCD_COL; i++)
  {arr[i] = ' ';}

  arr[LCD_COL] = '\0';

  length = pstr.length();
  pstr.toCharArray(arr1, length + 1); //analizar a fondo toCharArray

  uint8_t posc_f = posc_i + length;
  if (posc_f > LCD_COL)
  {posc_f = LCD_COL;}

  for (uint8_t i = posc_i; i < posc_f; i++)
  {
    arr[i] = arr1[c];
    c++;
  }
  return String(arr);
}
