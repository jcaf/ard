#ifndef ETHERNET_H_
#define ETHERNET_H_
    void ethernet_setup();
    void ethernetloop();
#endif // ETHERNET_H_

