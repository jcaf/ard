#ifndef BOOT_H_
#define BOOT_H_
    void sdcard_init(void);

    int8_t mainvar_ifexist(String setting_name);
    String  mainvar_getvalue(String setting_name);
    uint8_t mainvar_setvalue(String setting_name, String setting_value);

#endif // BOOT_H_
