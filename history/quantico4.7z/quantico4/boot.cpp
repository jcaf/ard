#include <Arduino.h>
#include "system.h"
#include "boot.h"
#include "errorsys.h"

#include <SPI.h>
#include <SD.h>

//Hard-definitions
#define cfgfiles_NUM_FILES 6
#define cfgfiles_NAME_FILE_LENGTH_MAX (8+1+3+1) //fat format 8.3 + \0

#define cfgfiles_directory "config/"

static void     sdcard_parsefiles(void);
static struct   _variable cfgfiles_getName_getValue(File *myFile, String * setting_name, String * setting_value);
static uint8_t  cfgfiles_save_mainvar( String * setting_name, String * setting_value);
static void     cfgfiles_save_mainvar_MAC(String * setting_value);

#define FUNCT_MODE_PRODUCTION   0
#define FUNCT_MODE_DEBUG        1
#define FUNCT_MODE_TESTING      2
uint8_t funct_mode;//=FUNCT_MODE_DEBUG;

//struct _cfgfiles_vars
//{
//    char [10][50];
//};
struct _cfgfiles
{
    char filename[cfgfiles_NAME_FILE_LENGTH_MAX];
    uint8_t num_vars;
    //struct _cfgfiles_vars cfgfiles_vars;

} cfgfiles[cfgfiles_NUM_FILES]=
{
    {"funcmod.txt",1},
    {"setcon.txt",9},
    {"specs.txt",3},
    {"setup.txt",4},
    {"corfact.txt",5},
    {"setacq.txt",6},
};

#define cfgfiles_VARIABLES_LENGTH_MAX 50
struct _mainvar
{
    const char setting_name[cfgfiles_VARIABLES_LENGTH_MAX];
    String setting_value;

} mainvar[]=
{
    //funcmod.txt
    {"FunctionMode","Production"},

    //setcon.txt
    {"MAC","0x90,0xA2,0xDA,0x0E,0x08,0x51"},
    {"Server1IP","192.168.1.45"},
    {"Host","quanticoservices.com"},
    {"Directory","monitor-v01-01"},
    {"ApiKeyW","2S25AHPLERPTOKFF"},

    //specs.txt
    {"SerialNumber","40773206"},

    //setup.txt

    //corfact.txt

    //setacq.txt
};


static uint8_t sdcard_lowlevel_ok(void)
{
    Sd2Card card;
    SdVolume volume;

    String errormsg;

    if (!card.init(SPI_HALF_SPEED, SDCARD_CS))
    {
        errormsg = errorsys("H10.1");// //+ String( card.errorCode() );
        return 0;
    }

    if (!volume.init(card))
    {
        errormsg = errorsys("H10.2");
        return 0;
    }

    String("Format: FAT")+String(volume.fatType());

    return 1;
}

void sdcard_init(void)
{
    String errormsg;

    //"Initializing ...";
    //"Running TEST: H10";

    if (sdcard_lowlevel_ok())
    {
        if (SD.begin(SDCARD_CS) )
        {
            if ( SD.open(cfgfiles_directory) == false)//in boolean context
            {
                errormsg = errorsys("H10.3");
            }
            else
            {
                sdcard_parsefiles();
            }
        }
    }

    //view main-variables
    //for (size_t i=0; i< sizeof(mainvar)/sizeof(mainvar[0]); i++)
    //    Serial.println(mainvar[i].setting_value);

}



struct _variable
{
    struct _bf
    {
        unsigned int sintax:1;
        unsigned int savevalue:1;
        unsigned int lcdprint:1;
        unsigned int __u:5;
    } bf;
};

static void sdcard_parsefiles(void)
{
    File myFile;
    char fileroute[10+cfgfiles_NAME_FILE_LENGTH_MAX] = cfgfiles_directory;
    String setting_name,setting_value;

    struct _variable variable;
    uint8_t variable_counter;

    for (uint8_t f=0; f<cfgfiles_NUM_FILES; f++)
    {
        strcpy(fileroute, cfgfiles_directory);
        strcat(fileroute, cfgfiles[f].filename);

        myFile = SD.open(fileroute);
        myFile.setTimeout(10);

        variable_counter = 0x00;

        while (myFile.available())
        {
            variable = cfgfiles_getName_getValue(&myFile, &setting_name, &setting_value);

            if (variable.bf.sintax)
            {
                variable_counter++;

                if (variable.bf.lcdprint)
                {
                    //lcd.print();
                }

                if ( !cfgfiles_save_mainvar( &setting_name, &setting_value) )
                {
                    //mainvar not found
                }

                if (funct_mode == FUNCT_MODE_DEBUG)
                {
                    Serial.print(setting_name);
                    Serial.print("=");
                    Serial.println(setting_value);
                }

            }
            //
        }

        myFile.close();

        if (variable_counter== cfgfiles[f].num_vars)//verified numbers of variables
        {
            if (funct_mode == FUNCT_MODE_DEBUG)
            {
                Serial.println("");Serial.println("Number of Variables found: OK");Serial.println("");
            }
        }
        else
        {
            if (funct_mode == FUNCT_MODE_DEBUG)
            {
                Serial.println("");Serial.println("Number of Variables found: BAD");Serial.println("");
            }
        }
    }
}

static struct _variable cfgfiles_getName_getValue(File *myFile, String * setting_name, String * setting_value)
{
    #define cfgfiles_VARS_LENGTH_MAX 30//x safe
    char buff[cfgfiles_VARS_LENGTH_MAX+20];

    struct _variable variable = {0};//all members to zero
    size_t var_length_max;
    int8_t sm0;
    char c;
    variable.bf.sintax = 1;
    variable.bf.lcdprint = 1;//x defect all variables are printable on LCD

    sm0=0x00;

    if (sm0 == 0)
    {
        if (myFile->find('['))
            sm0++;
        else
            sm0=-1;
                                                                                            //        while (myFile->available())
                                                                                            //        {
                                                                                            //            c = myFile->read();
                                                                                            //
                                                                                            //            if (c=='*')
                                                                                            //                variable.bf.savevalue=1;
                                                                                            //
                                                                                            //            if (c=='[')
                                                                                            //            {
                                                                                            //                sm0++;
                                                                                            //                break;
                                                                                            //            }
                                                                                            //        }
                                                                                            //        if (sm0==0)
                                                                                            //            sm0 = -1;

    }
    if (sm0 ==1)
    {
        var_length_max = myFile->readBytesUntil('=', buff, cfgfiles_VARS_LENGTH_MAX+20);//readBytesUntil is more safe than myFile.readStringUntil('=')

        if (var_length_max == cfgfiles_VARS_LENGTH_MAX+20)//error
            sm0 = -1;
        else
        {
            buff[var_length_max]='\0';
            *setting_name = String(buff);
            sm0++;
        }
    }
    if (sm0 ==2)
    {
        var_length_max = myFile->readBytesUntil(']', buff, cfgfiles_VARS_LENGTH_MAX+20);

        if (var_length_max == cfgfiles_VARS_LENGTH_MAX+20)//error
            sm0 = -1;
        else
        {
            buff[var_length_max]='\0';
            *setting_value= String(buff);
            sm0++;
        }
    }

    if (sm0 == -1)//Error
    {
        variable.bf.sintax = 0;
    }
    return variable;
}


static uint8_t cfgfiles_set_funct_mode(String *setting_value)
{
    uint8_t funct_mode = 0;

    if (*setting_value == "Production")
        funct_mode = 0;
    else if (*setting_value == "Debug")
        funct_mode = 1;
    else if (*setting_value == "Test")
        funct_mode = 2;

    return funct_mode;
}

static uint8_t cfgfiles_save_mainvar(String * setting_name, String * setting_value)
{
    uint8_t mainvar_found;

    mainvar_found = mainvar_setvalue(*setting_name, *setting_value);
    if (mainvar_found)
    {
        //_________________________________________________________
         if(*setting_name == "FunctionMode") {funct_mode = cfgfiles_set_funct_mode(setting_value);}
        //_________________________________________________________
    }
    return mainvar_found;
}

int8_t mainvar_ifexist(String setting_name)
{
    char setting_name_buff[cfgfiles_VARIABLES_LENGTH_MAX];
    int8_t index = -1;

    for (size_t i=0; i< sizeof(mainvar)/sizeof(mainvar[0]); i++)
    {
        setting_name.toCharArray(setting_name_buff, setting_name.length()+1 );

        if ( strcmp(mainvar[i].setting_name, setting_name_buff ) == 0 )
        {
            index = i;
            break;
        }
    }
    return index;
}


String mainvar_getvalue(String setting_name)
{
    String setting_value="";

    int8_t index = mainvar_ifexist(setting_name);
    if (index > -1)
        setting_value = mainvar[(size_t)index].setting_value;

    return setting_value;
}



uint8_t mainvar_setvalue(String setting_name, String setting_value)
{
    uint8_t mainvar_found = 0;

    int8_t index = mainvar_ifexist(setting_name);
    if (index > -1)
    {
        mainvar[(size_t)index].setting_value = setting_value;
        mainvar_found = 1;
    }

    return mainvar_found;
}

void cfgfiles_save_mainvar_MAC(String * setting_value)
{
    byte MAC[6];//= {0x00,0x00,0x00,0x00,0x00,0x00};

    #define arr_leng 30
    #define buff_length 10

    char arr[arr_leng];
    char buff[buff_length];
    uint8_t ca,cb,cm;

    setting_value->toCharArray(arr,arr_leng);

    ca=cb=cm=0;
    while (arr[ca] != '\0')
    {
        if (arr[ca]==',')
        {
            MAC[cm] =  (uint8_t) strtoul(buff, NULL, 16);
            cm++;
            ca++;//necesita 1 incremento x saltarse la coma
            cb=0;
            //limpieza del buffer
            for (int i=0; i<buff_length; i++)
                buff[i]=0;

        }
        buff[cb]=arr[ca];
        cb++;
        //
        ca++;
    }
    MAC[5] = (uint8_t) strtoul(buff, NULL, 16);

//    for (int i=0; i<6; i++)
//        Serial.println(MAC[i]);
}
