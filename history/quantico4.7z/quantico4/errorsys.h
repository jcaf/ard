#ifndef ERRORSYS_H_
#define ERRORSYS_H_

//    #define ERRORSYS_CODE_MAXCHAR 10//6+1
//    #define ERRORSYS_DESC_MAXCHAR 50

//    struct _errorsys_db
//    {
//        const char code[ERRORSYS_CODE_MAXCHAR];
//        const char desc[ERRORSYS_DESC_MAXCHAR];
//    };


    String errorsys(const char* code);

#endif // ERRORSYS_H_
