#ifndef FUELSENSOR_H_
#define FUELSENSOR_H_
    void fuelsensor_init(void);
    void fuelsensor_job(void);
#endif // FUELSENSOR_H_
