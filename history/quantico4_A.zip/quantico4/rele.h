#ifndef RELE_H_
#define RELE_H_

	#define NUM_RELE_MAX 5
	extern uint8_t rele[NUM_RELE_MAX];
	void rele_job(void);

#endif
