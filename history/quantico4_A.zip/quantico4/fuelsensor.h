#ifndef FUELSENSOR_H_
#define FUELSENSOR_H_

#include "spline.h"

enum FS_OUTPUTTYPE{LENGTH=0, VOLUME};

struct _fuelsensor
{
    uint8_t model;
    enum FS_OUTPUTTYPE outputType;

    struct _unitMeasurement
    {
        struct _length
        {
            float value;
            uint8_t units;
        } length;

        struct _volume
        {
            float value;
            uint8_t units;
        } volume;

    } unitMeasurement;

    struct _tank
    {
        uint8_t type;

        struct _rectangular
        {
            struct _area
            {
                uint8_t length;
                uint8_t width;
            } area;

        } rectangular;

        struct _irregular
        {
            //#define SPLINE_NODES_MAX 12//define in spline.h
            struct _spline
            {
                struct _node
                {
                    float X;//x
                    float A;//f(x)

                } node[SPLINE_NODES_MAX];

//                struct _units
//                {
//                    uint8_t height;
//                    uint8_t volume;
//                } units;

                //uint8_t A_Length;

                uint8_t node_counter;

            } spline;

        } irregular;

    } tank;

    struct _calib//ration
    {
        float effective_length;//meters
        struct _tank
        {
            float innertank;//cm
            float zero2full;
            float full2upper;

        }tank;

    } calib;//ration;
};

extern struct _fuelsensor fuelsensor;

#define FS_UNITMEA_LENGTH_METERS 0 //meters
#define FS_UNITMEA_LENGTH_CENTIMETERS 1 //centimeter
#define FS_UNITMEA_LENGTH_MILLIMETERS 2 //millimeters

#define FS_UNITMEA_VOLUME_GALLONS 0
#define FS_UNITMEA_VOLUME_LITERS 1
#define FS_UNITMEA_VOLUME_M3 2


#endif // FUELSENSOR_H_
