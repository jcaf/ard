#ifndef RS485_H_
#define RS485_H_

    #define RS485_DIR 6
    #define RS485_TX 1
    #define RS485_RX 0

#endif // RS485_H_
