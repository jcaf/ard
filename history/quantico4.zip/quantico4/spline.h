#ifndef SPLINE_H_
#define SPLINE_H_

    #define SPLINE_NODES_MAX 12//define in spline.h
    float get_spline(float xi, float *X, float *A, uint8_t A_Length);

#endif // SPLINE_H_
