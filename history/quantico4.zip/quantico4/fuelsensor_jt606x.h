#ifndef FUELSENSOR_JT606X_H_
#define FUELSENSOR_JT606X_H_

#define JT606_CMD_SET '1'  //ASCII
#define JT606_CMD_READ '0' //ASCII


#define JT606_CMD_CODE_SET_BAUDRATE      'A'
#define JT606_CMD_CODE_ZERO_ADJ          'B'
#define JT606_CMD_CODE_FULLRANGE_ADJ     'C'
#define JT606_CMD_CODE_SET_FUELTANKVOL   'D'
#define JT606_CMD_CODE_READ_FUELLEVEL    'E'
#define JT606_CMD_CODE_READSET_SENSORID  'G'
#define JT606_CMD_CODE_READSET_DAMPING   'H'
#define JT606_CMD_CODE_FACTORY_RESET     'T'
//
#define JT606_CMD_CODE_NUM_MAX 8

//------------------------------------------------------------------------------------------------------
union _jt606_send_zeroAdj
{
    struct _field
    {
        char head;//'@'
        char sensor_id[2];//ascci 00->99
        char cmd;//A-Z
        char content_length[2];//ascii-hex
        //
        char set_read;//ascii: Zero Setting for JT606. 0 means Read ,1 means Set
        //
        char checksum[2];//ascii
        char end;//'#'
    } field;
    char frame[];
};
#define JT606_SEND_ZERO_ADJ_FRAMELENGTH sizeof(union _jt606_send_zeroAdj)

union _jt606_reply_zeroAdj
{
    struct _field
    {
        char head;
        char sensor_id[2];
        char cmd;
        char content_length[2];
        //
        char internal_ad[4];//Internal AD value when emtpy fuel tank(Decimal System). it’s different from fuel level value.
        //Ignore this value when you analysis.
        //
        char checksum[2];
        char end;
    } field;
    char frame[];
};
#define JT606_REPLY_ZERO_ADJ_FRAMELENGTH sizeof(union _jt606_reply_zeroAdj)//13

//------------------------------------------------------------------------------------------------------
union _jt606_send_fullrangeAdj
{
    struct _field
    {
        char head;
        char sensor_id[2];
        char cmd;
        char content_length[2];
        //
        char set_read;//Full-range Setting for JT606. 0 means Read ,1 means Set
        //
        char checksum[2];
        char end;
    } field;
    char frame[];
};
#define JT606_SEND_FULLRANGE_ADJ_FRAMELENGTH sizeof(union _jt606_send_zeroAdj)

union _jt606_reply_fullrangeAdj
{
    struct _field
    {
        char head;
        char sensor_id[2];
        char cmd;
        char content_length[2];
        //
        char internal_ad[4];//Internal AD value when emtpy fuel tank(Decimal System). it’s different from fuel level value.
        //Ignore this value when you analysis.
        //
        char checksum[2];
        char end;
    } field;
    char frame[];
};
#define JT606_REPLY_FULLRANGE_ADJ_FRAMELENGTH sizeof(union _jt606_reply_fullrangeAdj)//13

//------------------------------------------------------------------------------------------------------
union _jt606_send_readFuelLevel
{
    struct _field
    {
        char head;
        char sensor_id[2];
        char cmd;
        char content_length[2];
        //
        char checksum[2];
        char end;
    } field;
    char frame[];
};
#define JT606_SEND_READ_FUELLEVEL_FRAMELENGTH sizeof(union _jt606_send_readFuelLevel)

union _jt606_reply_readFuelLevel
{
    struct _field
    {
        char head;
        char sensor_id[2];
        char cmd;
        char content_length[2];
        //
        char percentage[5];
        char advalue[4];//0-4095
        char litres[6];
        char fixed_val_zero;//0
        char reserved[3];
        //
        char checksum[2];
        char end;
    } field;

    //char frame[JT606_REPLY_LEVEL_VALUE_FRAMELENGTH];
    char frame[];
};
#define JT606_REPLY_READ_FUELLEVEL_FRAMELENGTH sizeof(union _jt606_reply_readFuelLevel)
//------------------------------------------------------------------------------------------------------

void jt606_run(void);

#endif // FUELSENSOR_JT606X_H_
