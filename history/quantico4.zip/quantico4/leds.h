#ifndef LEDS_H_
#define LEDS_H_
	#define NUM_LEDS_MAX 6
	extern uint8_t out_leds[NUM_LEDS_MAX];
	void out_leds_job(void);

#endif
