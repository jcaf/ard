#ifndef MENU_STACKINDETAIL_V_H_
#define MENU_STACKINDETAIL_V_H_

    struct _stackInDetail_V
    {
        int8_t sm0;
    };
    extern struct _stackInDetail_V stackInDetail_V;


    void stackInDetail_V_job(void);

#endif // MENU_STACKINDETAIL_V_H_
