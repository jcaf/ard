#ifndef OPENWIRE_H_
#define OPENWIRE_H_

    uint8_t openwire_2v(uint8_t num_ic);
    uint8_t openwire_12v(uint8_t num_ic);


#endif
