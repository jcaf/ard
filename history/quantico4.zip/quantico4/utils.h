#ifndef UTILS_H_
#define UTILS_H_
    uint8_t dec2bcd(uint8_t dec);
    char bin_to_asciihex(char c);
#endif // UTILS
