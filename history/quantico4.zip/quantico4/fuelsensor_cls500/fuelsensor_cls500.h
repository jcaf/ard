#ifndef FUELSENSOR_CLS500_H_
#define FUELSENSOR_CLS500_H_
    void fuelsensor_init(void);
    void fuelsensor_job(void);
#endif // FUELSENSOR_CLS500_H_
