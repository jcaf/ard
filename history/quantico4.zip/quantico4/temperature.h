#ifndef TEMPERATURE_H_
#define TEMPERATURE_H_

  float ntc10k_st(uint16_t ADC_CURRENT_VAL, uint16_t ADC_TOP_VAL);
#endif
